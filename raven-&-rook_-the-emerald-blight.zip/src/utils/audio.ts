/**
 * Procedural horror audio engine using Web Audio API.
 * Synthesizes eerie ambient drones, accelerating heartbeats, toxic drips, and monster stings.
 */

class HorrorAudioEngine {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private isMuted: boolean = true;
  private isInitialized: boolean = false;
  private volume: number = 0.6;

  // Drone nodes
  private droneOsc1: OscillatorNode | null = null;
  private droneOsc2: OscillatorNode | null = null;
  private subOsc: OscillatorNode | null = null;
  private droneFilter: BiquadFilterNode | null = null;
  private droneGain: GainNode | null = null;

  // Heartbeat state
  private heartbeatInterval: number | null = null;
  private currentBpm: number = 60;

  // Toxic drip timer
  private dripInterval: number | null = null;

  public init() {
    if (this.isInitialized && this.ctx) {
      if (this.ctx.state === 'suspended') {
        this.ctx.resume();
      }
      return;
    }

    try {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AudioCtx();
      this.masterGain = this.ctx.createGain();
      this.masterGain.gain.setValueAtTime(this.isMuted ? 0 : this.volume, this.ctx.currentTime);
      this.masterGain.connect(this.ctx.destination);

      this.startAmbientDrone();
      this.startToxicDrips();
      this.setHeartbeatBpm(60);

      this.isInitialized = true;
    } catch (e) {
      console.warn('Web Audio API not supported or blocked:', e);
    }
  }

  public toggleMute(): boolean {
    if (!this.isInitialized) {
      this.init();
      this.isMuted = false;
      if (this.masterGain && this.ctx) {
        this.masterGain.gain.setValueAtTime(this.volume, this.ctx.currentTime);
      }
      return false; // not muted
    }

    this.isMuted = !this.isMuted;
    if (this.ctx && this.masterGain) {
      const target = this.isMuted ? 0 : this.volume;
      this.masterGain.gain.setTargetAtTime(target, this.ctx.currentTime, 0.1);
      if (!this.isMuted && this.ctx.state === 'suspended') {
        this.ctx.resume();
      }
    }
    return this.isMuted;
  }

  public getIsMuted(): boolean {
    return this.isMuted;
  }

  public setVolume(vol: number) {
    this.volume = Math.max(0, Math.min(1, vol));
    if (this.ctx && this.masterGain && !this.isMuted) {
      this.masterGain.gain.setTargetAtTime(this.volume, this.ctx.currentTime, 0.05);
    }
  }

  private startAmbientDrone() {
    if (!this.ctx || !this.masterGain) return;

    // Deep sub bass drone
    this.subOsc = this.ctx.createOscillator();
    this.subOsc.type = 'sine';
    this.subOsc.frequency.setValueAtTime(43, this.ctx.currentTime); // Low F#

    // Detuned eerie saws
    this.droneOsc1 = this.ctx.createOscillator();
    this.droneOsc1.type = 'sawtooth';
    this.droneOsc1.frequency.setValueAtTime(65.4, this.ctx.currentTime); // C2

    this.droneOsc2 = this.ctx.createOscillator();
    this.droneOsc2.type = 'sawtooth';
    this.droneOsc2.frequency.setValueAtTime(64.8, this.ctx.currentTime); // Slight beat frequency

    this.droneFilter = this.ctx.createBiquadFilter();
    this.droneFilter.type = 'lowpass';
    this.droneFilter.frequency.setValueAtTime(140, this.ctx.currentTime);
    this.droneFilter.Q.setValueAtTime(4, this.ctx.currentTime);

    this.droneGain = this.ctx.createGain();
    this.droneGain.gain.setValueAtTime(0.22, this.ctx.currentTime);

    this.subOsc.connect(this.droneGain);
    this.droneOsc1.connect(this.droneFilter);
    this.droneOsc2.connect(this.droneFilter);
    this.droneFilter.connect(this.droneGain);
    this.droneGain.connect(this.masterGain);

    this.subOsc.start();
    this.droneOsc1.start();
    this.droneOsc2.start();
  }

  public updateDepthDrone(progress: number, monsterProximity: number = 0) {
    if (!this.ctx || !this.droneFilter || !this.subOsc) return;
    // As player descends or nears monsters, filter opens up, sub pitches down, drone intensifies
    const cutoff = 140 + progress * 320 + monsterProximity * 200;
    this.droneFilter.frequency.setTargetAtTime(cutoff, this.ctx.currentTime, 0.2);

    const subFreq = 43 - progress * 10;
    this.subOsc.frequency.setTargetAtTime(subFreq, this.ctx.currentTime, 0.2);

    // Dynamic BPM calculation: base 60-120bpm + up to +70bpm when monsters are near
    const newBpm = Math.round(60 + progress * 40 + monsterProximity * 90);
    if (Math.abs(newBpm - this.currentBpm) > 4) {
      this.setHeartbeatBpm(newBpm);
    }
  }

  public setHeartbeatBpm(bpm: number) {
    this.currentBpm = bpm;
    if (this.heartbeatInterval) {
      window.clearInterval(this.heartbeatInterval);
    }

    const intervalMs = (60 / bpm) * 1000;
    this.heartbeatInterval = window.setInterval(() => {
      if (!this.isMuted && this.ctx && this.ctx.state === 'running') {
        this.playHeartbeatThump();
      }
    }, intervalMs);
  }

  private playHeartbeatThump() {
    if (!this.ctx || !this.masterGain || this.isMuted) return;

    const t = this.ctx.currentTime;
    
    // Lub
    const osc1 = this.ctx.createOscillator();
    const gain1 = this.ctx.createGain();
    osc1.type = 'sine';
    osc1.frequency.setValueAtTime(75, t);
    osc1.frequency.exponentialRampToValueAtTime(30, t + 0.12);
    gain1.gain.setValueAtTime(0.35, t);
    gain1.gain.exponentialRampToValueAtTime(0.001, t + 0.15);
    osc1.connect(gain1);
    gain1.connect(this.masterGain);
    osc1.start(t);
    osc1.stop(t + 0.16);

    // Dub (shortly after)
    const tDub = t + 0.18;
    const osc2 = this.ctx.createOscillator();
    const gain2 = this.ctx.createGain();
    osc2.type = 'sine';
    osc2.frequency.setValueAtTime(65, tDub);
    osc2.frequency.exponentialRampToValueAtTime(25, tDub + 0.15);
    gain2.gain.setValueAtTime(0.28, tDub);
    gain2.gain.exponentialRampToValueAtTime(0.001, tDub + 0.18);
    osc2.connect(gain2);
    gain2.connect(this.masterGain);
    osc2.start(tDub);
    osc2.stop(tDub + 0.19);
  }

  private startToxicDrips() {
    this.dripInterval = window.setInterval(() => {
      if (!this.isMuted && this.ctx && this.ctx.state === 'running' && Math.random() > 0.4) {
        this.playToxicDrip();
      }
    }, 2800);
  }

  public playToxicDrip() {
    if (!this.ctx || !this.masterGain || this.isMuted) return;
    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    const filter = this.ctx.createBiquadFilter();

    osc.type = 'sine';
    const startFreq = 1200 + Math.random() * 800;
    osc.frequency.setValueAtTime(startFreq, t);
    osc.frequency.exponentialRampToValueAtTime(300, t + 0.18);

    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(800, t);
    filter.Q.setValueAtTime(8, t);

    gain.gain.setValueAtTime(0.12, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.22);

    osc.connect(filter);
    filter.connect(gain);
    gain.connect(this.masterGain);

    osc.start(t);
    osc.stop(t + 0.24);
  }

  public playRavenScreech() {
    if (!this.ctx || !this.masterGain || this.isMuted) return;
    const t = this.ctx.currentTime;

    // High pitched bird of prey screech
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    const filter = this.ctx.createBiquadFilter();

    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(2400, t);
    osc.frequency.linearRampToValueAtTime(1800, t + 0.15);
    osc.frequency.linearRampToValueAtTime(2900, t + 0.35);
    osc.frequency.exponentialRampToValueAtTime(400, t + 0.8);

    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(2200, t);
    filter.Q.setValueAtTime(3, t);

    gain.gain.setValueAtTime(0.001, t);
    gain.gain.linearRampToValueAtTime(0.3, t + 0.1);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.85);

    osc.connect(filter);
    filter.connect(gain);
    gain.connect(this.masterGain);

    osc.start(t);
    osc.stop(t + 0.9);
  }

  public playRookRoar() {
    if (!this.ctx || !this.masterGain || this.isMuted) return;
    const t = this.ctx.currentTime;

    // Heavy guttural sub rumble + distortion
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    const filter = this.ctx.createBiquadFilter();

    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(110, t);
    osc.frequency.linearRampToValueAtTime(45, t + 0.5);
    osc.frequency.exponentialRampToValueAtTime(28, t + 1.2);

    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(280, t);
    filter.Q.setValueAtTime(6, t);

    gain.gain.setValueAtTime(0.001, t);
    gain.gain.linearRampToValueAtTime(0.4, t + 0.2);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 1.3);

    osc.connect(filter);
    filter.connect(gain);
    gain.connect(this.masterGain);

    osc.start(t);
    osc.stop(t + 1.4);
  }

  public playThunder() {
    if (!this.ctx || !this.masterGain || this.isMuted) return;
    const t = this.ctx.currentTime;

    // White noise burst with lowpass sweep
    const bufferSize = this.ctx.sampleRate * 2;
    const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      data[i] = Math.random() * 2 - 1;
    }

    const noise = this.ctx.createBufferSource();
    noise.buffer = buffer;

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(600, t);
    filter.frequency.exponentialRampToValueAtTime(80, t + 1.8);

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(0.45, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 2.0);

    noise.connect(filter);
    filter.connect(gain);
    gain.connect(this.masterGain);

    noise.start(t);
    noise.stop(t + 2.1);
  }

  public destroy() {
    if (this.heartbeatInterval) window.clearInterval(this.heartbeatInterval);
    if (this.dripInterval) window.clearInterval(this.dripInterval);
    if (this.ctx && this.ctx.state !== 'closed') {
      this.ctx.close();
    }
  }
}

export const horrorAudio = new HorrorAudioEngine();
