/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Mansion3DScene } from './components/Mansion3DScene';
import { NavigationHeader } from './components/NavigationHeader';
import { SanityHUD } from './components/SanityHUD';
import { StoryOverlays } from './components/StoryOverlays';
import { DownloadSection } from './components/DownloadSection';
import { AshParticles } from './components/AshParticles';
import { JournalLog, JOURNAL_ENTRIES } from './components/JournalLog';
import { horrorAudio } from './utils/audio';

export default function App() {
  const [scrollProgress, setScrollProgress] = useState<number>(0);
  const [flashlightOn, setFlashlightOn] = useState<boolean>(true);
  const [nightVision, setNightVision] = useState<boolean>(false);
  const [activeMonster, setActiveMonster] = useState<'raven' | 'rook' | null>(null);

  // Journal State
  const [isJournalOpen, setIsJournalOpen] = useState(false);
  const [unlockedLogs, setUnlockedLogs] = useState<string[]>(['entry-1']);
  const [hasNewLog, setHasNewLog] = useState(false);

  // Chromatic Aberration intensity
  const [caIntensity, setCaIntensity] = useState(0);

  // Audio heartbeat & drone depth sync (accelerates near Raven or Rook)
  useEffect(() => {
    const distRaven = Math.abs(scrollProgress - 0.40);
    const distRook = Math.abs(scrollProgress - 0.78);
    const ravenProx = Math.max(0, 1 - distRaven / 0.16);
    const rookProx = Math.max(0, 1 - distRook / 0.16);
    let prox = Math.max(ravenProx, rookProx);
    if (activeMonster) prox = Math.max(prox, 0.85);

    setCaIntensity(prox); // Map proximity directly to CA intensity
    horrorAudio.updateDepthDrone(scrollProgress, prox);

    // Check for journal unlocks
    const newlyUnlocked = JOURNAL_ENTRIES.filter(
      (entry) => scrollProgress >= entry.unlockedAtProgress && !unlockedLogs.includes(entry.id)
    );

    if (newlyUnlocked.length > 0) {
      setUnlockedLogs((prev) => [...prev, ...newlyUnlocked.map((e) => e.id)]);
      setHasNewLog(true);
      // Play a subtle log unlock sound if desired, dripping sound is generic but works.
      // horrorAudio.playToxicDrip();
    }
  }, [scrollProgress, activeMonster, unlockedLogs]);

  // Scroll Progress Tracking
  const ticking = useRef(false);
  const handleScroll = useCallback(() => {
    if (!ticking.current) {
      requestAnimationFrame(() => {
        const totalHeight = document.documentElement.scrollHeight - window.innerHeight;
        if (totalHeight > 0) {
          const progress = Math.max(0, Math.min(1, window.scrollY / totalHeight));
          setScrollProgress(progress);
        }
        ticking.current = false;
      });
      ticking.current = true;
    }
  }, []);

  useEffect(() => {
    window.addEventListener('scroll', handleScroll, { passive: true });
    handleScroll();
    return () => window.removeEventListener('scroll', handleScroll);
  }, [handleScroll]);

  // Keyboard Shortcuts (F: Flashlight, M: Mute, N: Night Vision)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'f' || e.key === 'F') {
        setFlashlightOn((prev) => !prev);
        horrorAudio.playToxicDrip();
      } else if (e.key === 'm' || e.key === 'M') {
        horrorAudio.toggleMute();
      } else if (e.key === 'n' || e.key === 'N') {
        setNightVision((prev) => !prev);
        horrorAudio.playToxicDrip();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Jump smoothly to scroll progress
  const jumpToProgress = useCallback((progress: number) => {
    const totalHeight = document.documentElement.scrollHeight - window.innerHeight;
    window.scrollTo({
      top: progress * totalHeight,
      behavior: 'smooth',
    });
  }, []);

  const scrollToNext = useCallback(() => {
    const nextY = window.scrollY + window.innerHeight * 0.85;
    window.scrollTo({ top: nextY, behavior: 'smooth' });
  }, []);

  return (
    <div className="relative min-h-screen bg-[#020202] text-zinc-300 font-serif overflow-x-hidden selection:bg-[#FF1E27]/30 selection:text-[#FF1E27]">
      {/* SVG Filter for Screen-Space Chromatic Aberration */}
      <svg style={{ position: 'absolute', width: 0, height: 0 }} aria-hidden="true">
        <filter id="chromatic-aberration" colorInterpolationFilters="sRGB">
          {/* Shift red channel right */}
          <feOffset in="SourceGraphic" dx={caIntensity * 6} dy="0" result="red-shift" />
          <feColorMatrix in="red-shift" type="matrix" values="1 0 0 0 0  0 0 0 0 0  0 0 0 0 0  0 0 0 1 0" result="red" />
          
          {/* Shift blue channel left */}
          <feOffset in="SourceGraphic" dx={-caIntensity * 6} dy="0" result="blue-shift" />
          <feColorMatrix in="blue-shift" type="matrix" values="0 0 0 0 0  0 0 0 0 0  0 0 1 0 0  0 0 0 1 0" result="blue" />
          
          {/* Keep green channel centered */}
          <feColorMatrix in="SourceGraphic" type="matrix" values="0 0 0 0 0  0 1 0 0 0  0 0 0 0 0  0 0 0 1 0" result="green" />
          
          {/* Blend together */}
          <feBlend mode="screen" in="red" in2="green" result="blend1" />
          <feBlend mode="screen" in="blend1" in2="blue" result="blend2" />
        </filter>
      </svg>

      {/* 3D Mansion Canvas (Fixed Fullscreen Background) */}
      <div style={caIntensity > 0.05 ? { filter: 'url(#chromatic-aberration)' } : undefined}>
        <Mansion3DScene
          scrollProgress={scrollProgress}
          flashlightOn={flashlightOn}
          nightVision={nightVision}
          onMonsterSight={setActiveMonster}
        />
      </div>

      {/* Post-Processing Application Layer */}
      <div className="relative z-10 w-full min-h-screen">
        {/* Atmospheric Ambient Glow & Scanlines Layer */}
        <AshParticles />
        <div className="fixed inset-0 ambient-crimson-glow pointer-events-none z-10 -translate-y-1/4" />
        <div className="fixed inset-0 scanlines-overlay pointer-events-none z-10" />
        <div className="fixed inset-0 vignette-overlay pointer-events-none z-10" />
        <div className="fixed top-0 left-0 w-full h-32 bg-gradient-to-b from-black to-transparent opacity-80 pointer-events-none z-10" />

        {/* Persistent Immersive System Indicators in Corner */}
        <div className="fixed bottom-8 left-8 z-30 pointer-events-none hidden md:flex flex-col gap-2.5">
          <div className="w-2 h-2 rounded-full bg-[#FF1E27] animate-pulse shadow-[0_0_8px_#FF1E27]" />
          <div className="w-2 h-2 rounded-full bg-[#FF1E27]/30" />
          <div className="w-2 h-2 rounded-full bg-[#FF1E27]/30" />
        </div>

        <div className="fixed bottom-8 right-8 z-30 pointer-events-none hidden md:block">
          <span className="text-[10px] text-zinc-500 uppercase tracking-widest font-mono-horror writing-vertical select-none">
            Mansion System Rev. 1.04 // Sector Sub-04
          </span>
        </div>

        {/* Dynamic Sanity & Depth HUD */}
        <SanityHUD
          scrollProgress={scrollProgress}
          activeMonster={activeMonster}
          onScrollDown={scrollToNext}
        />

        {/* Main Narrative Scroll Content */}
        <main className="relative z-20 pointer-events-auto">
          <StoryOverlays
            onScrollToNext={scrollToNext}
            onJumpToChapter={jumpToProgress}
          />

          {/* Grand Finale: Massive Pulsating Download Button Section */}
          <DownloadSection />
        </main>
      </div>

      {/* Elements outside chromatic aberration (Nav & Drawers) */}
      <NavigationHeader
        scrollProgress={scrollProgress}
        nightVision={nightVision}
        hasNewLog={hasNewLog}
        onToggleNightVision={() => setNightVision((prev) => !prev)}
        onJumpToChapter={jumpToProgress}
        onOpenJournal={() => {
          setIsJournalOpen(true);
          setHasNewLog(false);
        }}
      />

      <JournalLog 
        isOpen={isJournalOpen} 
        onClose={() => setIsJournalOpen(false)} 
        unlockedLogs={unlockedLogs} 
      />
    </div>
  );
}
