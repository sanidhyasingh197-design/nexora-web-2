import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';

interface Mansion3DSceneProps {
  scrollProgress: number; // 0.0 to 1.0
  flashlightOn: boolean;
  onMonsterSight?: (monster: 'raven' | 'rook' | null) => void;
  nightVision?: boolean;
}

export const Mansion3DScene: React.FC<Mansion3DSceneProps> = ({
  scrollProgress,
  flashlightOn,
  onMonsterSight,
  nightVision = false,
}) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const mousePosRef = useRef({ x: 0, y: 0, targetX: 0, targetY: 0 });
  const [fps, setFps] = useState<number>(60);
  const [webGlSupported, setWebGlSupported] = useState<boolean>(true);

  // Animation and scene refs
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const flashlightRef = useRef<THREE.SpotLight | null>(null);
  const flashlightTargetRef = useRef<THREE.Object3D | null>(null);
  const animFrameIdRef = useRef<number | null>(null);

  // Animated elements refs
  const emeraldCoreRef = useRef<THREE.Mesh | null>(null);
  const coreRingsRef = useRef<THREE.Group | null>(null);
  const particlesRef = useRef<THREE.Points | null>(null);
  const ravenWingLeftRef = useRef<THREE.Group | null>(null);
  const ravenWingRightRef = useRef<THREE.Group | null>(null);
  const rookArmLeftRef = useRef<THREE.Group | null>(null);
  const rookArmRightRef = useRef<THREE.Group | null>(null);
  const toxicRiverRef = useRef<THREE.Mesh | null>(null);
  const flickerLightsRef = useRef<THREE.PointLight[]>([]);

  // Smooth scroll target lerping
  const targetProgressRef = useRef<number>(0);
  const currentProgressRef = useRef<number>(0);

  useEffect(() => {
    targetProgressRef.current = scrollProgress;
  }, [scrollProgress]);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    // Check WebGL support
    try {
      const testCanvas = document.createElement('canvas');
      const gl = testCanvas.getContext('webgl') || testCanvas.getContext('experimental-webgl');
      if (!gl) {
        setWebGlSupported(false);
        return;
      }
    } catch {
      setWebGlSupported(false);
      return;
    }

    // Initialize Scene
    const scene = new THREE.Scene();
    sceneRef.current = scene;
    scene.fog = new THREE.FogExp2(0x080202, 0.024);

    // Initialize Camera
    const camera = new THREE.PerspectiveCamera(
      60,
      container.clientWidth / container.clientHeight,
      0.1,
      150
    );
    camera.position.set(0, 12, 22);
    cameraRef.current = camera;

    // Initialize Renderer
    const renderer = new THREE.WebGLRenderer({
      antialias: true,
      powerPreference: 'high-performance',
      alpha: true,
    });
    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.1;
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    rendererRef.current = renderer;

    container.appendChild(renderer.domElement);

    // ==========================================
    // LIGHTING SYSTEM
    // ==========================================
    // Ambient moonlight / blight haze
    const ambientLight = new THREE.AmbientLight(0x180808, 0.5);
    scene.add(ambientLight);

    // Moonlight through stained glass at top
    const moonLight = new THREE.DirectionalLight(0x704040, 0.8);
    moonLight.position.set(10, 25, 20);
    scene.add(moonLight);

    // Flashlight
    const flashlight = new THREE.SpotLight(0xfff5f5, 4.5, 35, Math.PI / 6, 0.45, 1.2);
    flashlight.position.set(0, 12, 22);
    flashlight.castShadow = true;
    flashlight.shadow.mapSize.width = 1024;
    flashlight.shadow.mapSize.height = 1024;
    const flashlightTarget = new THREE.Object3D();
    scene.add(flashlightTarget);
    flashlight.target = flashlightTarget;
    scene.add(flashlight);
    flashlightRef.current = flashlight;
    flashlightTargetRef.current = flashlightTarget;

    // Pulsing crimson point lights placed throughout vertical zones
    const lightPositions: [number, number, number, number, string][] = [
      [0, 8, 14, 2.5, '#FF1E27'],     // Foyer Chandelier
      [-4, 2, 6, 1.8, '#ef4444'],     // Foyer Sconce Left
      [4, 2, 6, 1.8, '#ef4444'],      // Foyer Sconce Right
      [0, -8, 2, 3.2, '#FF1E27'],     // Portrait Hall
      [-3, -22, -6, 4.0, '#ff3344'],  // Raven's Roost
      [3, -45, -20, 5.0, '#ff2233'],  // Crimson Lab Vats
      [0, -68, -32, 6.5, '#FF1E27'],  // Crypt Sarcophagus
      [0, -84, -45, 10.0, '#ff1122'], // The Core Monolith
    ];

    flickerLightsRef.current = [];
    lightPositions.forEach(([x, y, z, intensity, colorHex]) => {
      const pl = new THREE.PointLight(new THREE.Color(colorHex), intensity, 25, 1.4);
      pl.position.set(x, y, z);
      scene.add(pl);
      flickerLightsRef.current.push(pl);
    });

    // ==========================================
    // PROCEDURAL TEXTURES & MATERIALS
    // ==========================================
    // Stone texture helper
    const createStoneTexture = () => {
      const canvas = document.createElement('canvas');
      canvas.width = 256;
      canvas.height = 256;
      const ctx = canvas.getContext('2d')!;
      ctx.fillStyle = '#1c1515';
      ctx.fillRect(0, 0, 256, 256);
      for (let i = 0; i < 2000; i++) {
        const x = Math.random() * 256;
        const y = Math.random() * 256;
        const radius = Math.random() * 3;
        ctx.fillStyle = Math.random() > 0.6 ? '#100a0a' : '#2d2222';
        ctx.beginPath();
        ctx.arc(x, y, radius, 0, Math.PI * 2);
        ctx.fill();
      }
      // Crimson toxic veins in stone
      ctx.strokeStyle = 'rgba(255, 30, 39, 0.15)';
      ctx.lineWidth = 1.5;
      for (let j = 0; j < 6; j++) {
        ctx.beginPath();
        ctx.moveTo(Math.random() * 256, 0);
        ctx.bezierCurveTo(
          Math.random() * 256, 80,
          Math.random() * 256, 160,
          Math.random() * 256, 256
        );
        ctx.stroke();
      }
      return new THREE.CanvasTexture(canvas);
    };

    const stoneTexture = createStoneTexture();
    stoneTexture.wrapS = THREE.RepeatWrapping;
    stoneTexture.wrapT = THREE.RepeatWrapping;
    stoneTexture.repeat.set(4, 8);

    const stoneMaterial = new THREE.MeshStandardMaterial({
      map: stoneTexture,
      roughness: 0.85,
      metalness: 0.2,
      color: 0x332424,
    });

    const woodMaterial = new THREE.MeshStandardMaterial({
      roughness: 0.9,
      metalness: 0.1,
      color: 0x1a120c,
    });

    const darkIronMaterial = new THREE.MeshStandardMaterial({
      roughness: 0.4,
      metalness: 0.85,
      color: 0x241c1c,
    });

    const toxicGlowingMaterial = new THREE.MeshStandardMaterial({
      color: 0xFF1E27,
      emissive: 0xFF1E27,
      emissiveIntensity: 2.2,
      roughness: 0.15,
      metalness: 0.1,
      transparent: true,
      opacity: 0.88,
    });

    // ==========================================
    // 3D ENVIRONMENT ARCHITECTURE
    // ==========================================

    // Outer manor stone tunnel / walls
    const shaftGeo = new THREE.CylinderGeometry(14, 18, 120, 16, 20, true);
    shaftGeo.scale(-1, 1, 1); // Invert normals to view from inside
    const shaftMesh = new THREE.Mesh(shaftGeo, stoneMaterial);
    shaftMesh.position.set(0, -35, -15);
    scene.add(shaftMesh);

    // --- ZONE 1: GRAND FOYER (Y: 15 to 0, Z: 25 to 10) ---
    // Stained Glass Window at the peak
    const windowGroup = new THREE.Group();
    const frameGeo = new THREE.TorusGeometry(5, 0.4, 8, 24);
    const frameMesh = new THREE.Mesh(frameGeo, darkIronMaterial);
    windowGroup.add(frameMesh);

    const glassGeo = new THREE.CircleGeometry(4.8, 24);
    const glassMat = new THREE.MeshStandardMaterial({
      color: 0xff3344,
      emissive: 0xFF1E27,
      emissiveIntensity: 0.6,
      transparent: true,
      opacity: 0.4,
      side: THREE.DoubleSide,
    });
    const glassMesh = new THREE.Mesh(glassGeo, glassMat);
    windowGroup.add(glassMesh);
    windowGroup.position.set(0, 16, 8);
    scene.add(windowGroup);

    // Broken Grand Staircase
    const stairSteps = 14;
    for (let i = 0; i < stairSteps; i++) {
      const stepGeo = new THREE.BoxGeometry(10 - i * 0.3, 0.6, 2);
      const stepMesh = new THREE.Mesh(stepGeo, woodMaterial);
      stepMesh.position.set(0, 12 - i * 0.8, 18 - i * 1.3);
      stepMesh.receiveShadow = true;
      scene.add(stepMesh);
    }

    // Gothic Archway Pillars
    for (let i = 0; i < 4; i++) {
      const pillarGeo = new THREE.CylinderGeometry(0.8, 0.9, 16, 8);
      const leftPillar = new THREE.Mesh(pillarGeo, stoneMaterial);
      leftPillar.position.set(-6, 8, 18 - i * 6);
      scene.add(leftPillar);

      const rightPillar = new THREE.Mesh(pillarGeo, stoneMaterial);
      rightPillar.position.set(6, 8, 18 - i * 6);
      scene.add(rightPillar);
    }

    // --- ZONE 2: PORTRAIT GALLERY (Y: 0 to -20, Z: 10 to 0) ---
    const createPortrait = (label: string, isRaven: boolean) => {
      const group = new THREE.Group();
      const pFrame = new THREE.Mesh(new THREE.BoxGeometry(3.2, 4.5, 0.2), darkIronMaterial);
      group.add(pFrame);

      // Canvas inside
      const pCanvas = document.createElement('canvas');
      pCanvas.width = 256;
      pCanvas.height = 360;
      const ctx = pCanvas.getContext('2d')!;
      ctx.fillStyle = '#100606';
      ctx.fillRect(0, 0, 256, 360);
      
      // Figure silhouette
      ctx.fillStyle = isRaven ? '#2e0c0c' : '#221a1a';
      ctx.beginPath();
      ctx.arc(128, 110, 45, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillRect(90, 150, 76, 160);

      // Glowing crimson eyes
      ctx.fillStyle = '#FF1E27';
      ctx.shadowColor = '#FF1E27';
      ctx.shadowBlur = 12;
      ctx.fillRect(115, 105, 8, 8);
      ctx.fillRect(135, 105, 8, 8);

      // Text label
      ctx.fillStyle = '#ffa0a0';
      ctx.font = 'bold 16px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText(label, 128, 335);

      const texture = new THREE.CanvasTexture(pCanvas);
      const canvasMesh = new THREE.Mesh(
        new THREE.PlaneGeometry(2.9, 4.2),
        new THREE.MeshStandardMaterial({
          map: texture,
          emissive: 0xFF1E27,
          emissiveIntensity: 0.25,
        })
      );
      canvasMesh.position.z = 0.12;
      group.add(canvasMesh);

      return group;
    };

    const ravenPortrait = createPortrait('RAVEN BLACKWOOD', true);
    ravenPortrait.position.set(-6.5, -6, 4);
    ravenPortrait.rotation.y = Math.PI / 2.8;
    scene.add(ravenPortrait);

    const rookPortrait = createPortrait('ROOK BLACKWOOD', false);
    rookPortrait.position.set(6.5, -6, 4);
    rookPortrait.rotation.y = -Math.PI / 2.8;
    scene.add(rookPortrait);

    // --- ZONE 3: RAVEN'S SHADOW RAFTERS (Y: -20 to -40, Z: 0 to -15) ---
    // Wooden rafters crossing the shaft
    for (let r = 0; r < 5; r++) {
      const beam = new THREE.Mesh(new THREE.BoxGeometry(16, 0.8, 0.8), woodMaterial);
      beam.position.set(0, -22 - r * 4, 2 - r * 4);
      beam.rotation.y = (r % 2 === 0 ? 0.2 : -0.2);
      scene.add(beam);
    }

    // RAVEN 3D MONSTER AVATAR (Perched above)
    const ravenGroup = new THREE.Group();
    // Torso / cloak
    const ravenTorso = new THREE.Mesh(
      new THREE.ConeGeometry(1.2, 3.8, 6),
      new THREE.MeshStandardMaterial({ color: 0x110707, roughness: 0.8 })
    );
    ravenGroup.add(ravenTorso);

    // Mask / Beak
    const beakMesh = new THREE.Mesh(
      new THREE.ConeGeometry(0.3, 1.4, 4),
      new THREE.MeshStandardMaterial({ color: 0x381f1f, metalness: 0.6, roughness: 0.3 })
    );
    beakMesh.rotation.x = Math.PI / 2.2;
    beakMesh.position.set(0, 1.2, 0.9);
    ravenGroup.add(beakMesh);

    // Glowing Eyes
    const eyeMat = new THREE.MeshBasicMaterial({ color: 0xFF1E27 });
    const eyeL = new THREE.Mesh(new THREE.SphereGeometry(0.12, 8, 8), eyeMat);
    eyeL.position.set(-0.25, 1.4, 0.6);
    const eyeR = new THREE.Mesh(new THREE.SphereGeometry(0.12, 8, 8), eyeMat);
    eyeR.position.set(0.25, 1.4, 0.6);
    ravenGroup.add(eyeL, eyeR);

    // Wing Left
    const wingL = new THREE.Group();
    const wingMeshL = new THREE.Mesh(
      new THREE.BoxGeometry(4.5, 0.15, 1.8),
      new THREE.MeshStandardMaterial({ color: 0x0f0505, roughness: 0.9 })
    );
    wingMeshL.position.set(-2.2, 0, 0);
    wingL.add(wingMeshL);
    wingL.position.set(-0.6, 0.8, 0);
    ravenWingLeftRef.current = wingL;
    ravenGroup.add(wingL);

    // Wing Right
    const wingR = new THREE.Group();
    const wingMeshR = new THREE.Mesh(
      new THREE.BoxGeometry(4.5, 0.15, 1.8),
      new THREE.MeshStandardMaterial({ color: 0x0f0505, roughness: 0.9 })
    );
    wingMeshR.position.set(2.2, 0, 0);
    wingR.add(wingMeshR);
    wingR.position.set(0.6, 0.8, 0);
    ravenWingRightRef.current = wingR;
    ravenGroup.add(wingR);

    ravenGroup.position.set(-3.5, -24, -6);
    ravenGroup.rotation.y = 0.5;
    scene.add(ravenGroup);

    // --- ZONE 4: THE BLIGHTED LABORATORY (Y: -40 to -65, Z: -15 to -30) ---
    // Giant Alchemical Vats / Tubes
    for (let v = 0; v < 3; v++) {
      const vatGeo = new THREE.CylinderGeometry(1.8, 1.8, 7, 16);
      const vatMat = new THREE.MeshStandardMaterial({
        color: 0xFF1E27,
        emissive: 0xaa0011,
        emissiveIntensity: 0.8,
        transparent: true,
        opacity: 0.5,
        roughness: 0.1,
      });
      const vatMesh = new THREE.Mesh(vatGeo, vatMat);
      vatMesh.position.set(-5 + v * 5, -48, -22);
      scene.add(vatMesh);

      // Iron rings on vats
      const ringGeo = new THREE.TorusGeometry(1.9, 0.15, 8, 16);
      const ringMesh = new THREE.Mesh(ringGeo, darkIronMaterial);
      ringMesh.rotation.x = Math.PI / 2;
      ringMesh.position.set(-5 + v * 5, -48, -22);
      scene.add(ringMesh);
    }

    // Seeping Crimson Waterfall / Sludge River
    const riverGeo = new THREE.PlaneGeometry(8, 26, 12, 24);
    const riverMesh = new THREE.Mesh(riverGeo, toxicGlowingMaterial);
    riverMesh.rotation.x = -Math.PI / 2.6;
    riverMesh.position.set(0, -56, -26);
    scene.add(riverMesh);
    toxicRiverRef.current = riverMesh;

    // ROOK 3D JUGGERNAUT AVATAR (Towering at the bottom)
    const rookGroup = new THREE.Group();
    // Massive Torso / Bone Plate Armor
    const rookTorso = new THREE.Mesh(
      new THREE.BoxGeometry(3.8, 4.5, 2.8),
      new THREE.MeshStandardMaterial({ color: 0x241818, roughness: 0.95, metalness: 0.3 })
    );
    rookGroup.add(rookTorso);

    // Shoulder Horns
    const hornL = new THREE.Mesh(
      new THREE.ConeGeometry(0.8, 2.8, 6),
      new THREE.MeshStandardMaterial({ color: 0x170b0b, roughness: 0.7 })
    );
    hornL.rotation.z = Math.PI / 3;
    hornL.position.set(-2.4, 2.2, 0);
    const hornR = new THREE.Mesh(
      new THREE.ConeGeometry(0.8, 2.8, 6),
      new THREE.MeshStandardMaterial({ color: 0x170b0b, roughness: 0.7 })
    );
    hornR.rotation.z = -Math.PI / 3;
    hornR.position.set(2.4, 2.2, 0);
    rookGroup.add(hornL, hornR);

    // Glowing Crimson Chest Core
    const rookChestCore = new THREE.Mesh(
      new THREE.SphereGeometry(0.9, 12, 12),
      toxicGlowingMaterial
    );
    rookChestCore.position.set(0, 0.4, 1.2);
    rookGroup.add(rookChestCore);

    // Arms
    const armL = new THREE.Group();
    const armMeshL = new THREE.Mesh(
      new THREE.CylinderGeometry(0.7, 0.9, 4, 8),
      new THREE.MeshStandardMaterial({ color: 0x1f1414, roughness: 0.9 })
    );
    armMeshL.position.set(0, -2, 0);
    armL.add(armMeshL);
    armL.position.set(-2.4, 1.2, 0);
    rookArmLeftRef.current = armL;
    rookGroup.add(armL);

    const armR = new THREE.Group();
    const armMeshR = new THREE.Mesh(
      new THREE.CylinderGeometry(0.7, 0.9, 4, 8),
      new THREE.MeshStandardMaterial({ color: 0x1f1414, roughness: 0.9 })
    );
    armMeshR.position.set(0, -2, 0);
    armR.add(armMeshR);
    armR.position.set(2.4, 1.2, 0);
    rookArmRightRef.current = armR;
    rookGroup.add(armR);

    rookGroup.position.set(4.2, -65, -34);
    rookGroup.rotation.y = -0.6;
    scene.add(rookGroup);

    // --- ZONE 5: THE SUBTERRANEAN CRYPT & ABYSS CORE (Y: -65 to -90, Z: -30 to -50) ---
    // Massive Sarcophagi
    for (let s = 0; s < 4; s++) {
      const sarc = new THREE.Mesh(new THREE.BoxGeometry(2.4, 1.8, 5), stoneMaterial);
      sarc.position.set(s % 2 === 0 ? -6 : 6, -72 - Math.floor(s / 2) * 6, -34 - (s % 2) * 5);
      scene.add(sarc);
    }

    // THE CRIMSON CORE MONOLITH (At deepest level, scrollProgress = 1.0)
    const coreGroup = new THREE.Group();
    coreGroup.position.set(0, -84, -46);

    const coreGeo = new THREE.IcosahedronGeometry(3.4, 1);
    const coreMesh = new THREE.Mesh(coreGeo, toxicGlowingMaterial);
    emeraldCoreRef.current = coreMesh;
    coreGroup.add(coreMesh);

    // Orbiting Runic Rings
    const ringsGroup = new THREE.Group();
    for (let r = 0; r < 3; r++) {
      const ringTorus = new THREE.Mesh(
        new THREE.TorusGeometry(4.6 + r * 1.1, 0.12, 8, 32),
        darkIronMaterial
      );
      ringTorus.rotation.x = Math.PI / (2 + r);
      ringTorus.rotation.y = (r * Math.PI) / 3;
      ringsGroup.add(ringTorus);
    }
    coreRingsRef.current = ringsGroup;
    coreGroup.add(ringsGroup);
    scene.add(coreGroup);

    // ==========================================
    // FLOATING CRIMSON PARTICLES
    // ==========================================
    const particleCount = 1200;
    const particleGeo = new THREE.BufferGeometry();
    const particlePositions = new Float32Array(particleCount * 3);
    const particleScales = new Float32Array(particleCount);

    for (let p = 0; p < particleCount; p++) {
      particlePositions[p * 3] = (Math.random() - 0.5) * 28;
      particlePositions[p * 3 + 1] = 20 - Math.random() * 110; // Spans entire Y descent
      particlePositions[p * 3 + 2] = 25 - Math.random() * 75; // Spans entire Z descent
      particleScales[p] = Math.random() * 0.8 + 0.2;
    }

    particleGeo.setAttribute('position', new THREE.BufferAttribute(particlePositions, 3));
    particleGeo.setAttribute('scale', new THREE.BufferAttribute(particleScales, 1));

    // Particle Material
    const pMat = new THREE.PointsMaterial({
      color: 0xFF1E27,
      size: 0.45,
      transparent: true,
      opacity: 0.65,
      blending: THREE.AdditiveBlending,
    });

    const particles = new THREE.Points(particleGeo, pMat);
    particlesRef.current = particles;
    scene.add(particles);

    // ==========================================
    // MOUSE PARALLAX LISTENER
    // ==========================================
    const handleMouseMove = (e: MouseEvent) => {
      const rect = container.getBoundingClientRect();
      const x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      const y = -(((e.clientY - rect.top) / rect.height) * 2 - 1);
      mousePosRef.current.targetX = x;
      mousePosRef.current.targetY = y;
    };

    window.addEventListener('mousemove', handleMouseMove);

    // ==========================================
    // RESIZE LISTENER
    // ==========================================
    const handleResize = () => {
      if (!container || !rendererRef.current || !cameraRef.current) return;
      const w = container.clientWidth;
      const h = container.clientHeight;
      cameraRef.current.aspect = w / h;
      cameraRef.current.updateProjectionMatrix();
      rendererRef.current.setSize(w, h);
    };

    const resizeObserver = new ResizeObserver(handleResize);
    resizeObserver.observe(container);

    // ==========================================
    // CAMERA PATH SPLINE POINTS
    // ==========================================
    // Defined checkpoints across scroll descent
    const cameraSplinePoints = [
      new THREE.Vector3(0, 12, 22),       // 0%: Foyer Top
      new THREE.Vector3(1.5, 4, 14),      // 15%: Foyer Staircase
      new THREE.Vector3(-1.0, -5, 6),     // 30%: Portrait Corridor
      new THREE.Vector3(-2.2, -18, 0),    // 45%: Raven's Rafters
      new THREE.Vector3(2.0, -38, -14),   // 60%: Alchemical Descent
      new THREE.Vector3(-1.5, -55, -24),  // 75%: Toxic Lab & Sludge River
      new THREE.Vector3(1.2, -72, -34),   // 88%: Rook's Crypt
      new THREE.Vector3(0, -82, -41),     // 100%: Monolith Abyss & Download
    ];

    const lookAtSplinePoints = [
      new THREE.Vector3(0, 9, 10),        // 0%
      new THREE.Vector3(0, 0, 4),         // 15%
      new THREE.Vector3(0, -8, -2),       // 30%
      new THREE.Vector3(-2.5, -22, -6),   // 45% (Looking at Raven)
      new THREE.Vector3(0, -46, -20),     // 60%
      new THREE.Vector3(2.5, -62, -30),   // 75% (Looking at Rook)
      new THREE.Vector3(0, -78, -38),     // 88%
      new THREE.Vector3(0, -84, -48),     // 100% (Looking at Pulsing Core)
    ];

    const cameraCurve = new THREE.CatmullRomCurve3(cameraSplinePoints);
    const lookAtCurve = new THREE.CatmullRomCurve3(lookAtSplinePoints);

    // ==========================================
    // RENDER LOOP
    // ==========================================
    let lastTime = performance.now();
    let frameCount = 0;
    let lastFpsUpdate = performance.now();

    const animate = (time: number) => {
      animFrameIdRef.current = requestAnimationFrame(animate);

      // FPS tracking
      frameCount++;
      if (time - lastFpsUpdate > 1000) {
        setFps(Math.round((frameCount * 1000) / (time - lastFpsUpdate)));
        frameCount = 0;
        lastFpsUpdate = time;
      }

      const delta = (time - lastTime) * 0.001;
      lastTime = time;

      // Mouse smoothing
      mousePosRef.current.x += (mousePosRef.current.targetX - mousePosRef.current.x) * 0.05;
      mousePosRef.current.y += (mousePosRef.current.targetY - mousePosRef.current.y) * 0.05;

      // Smooth progress lerp
      currentProgressRef.current += (targetProgressRef.current - currentProgressRef.current) * 0.08;
      const p = Math.max(0, Math.min(1, currentProgressRef.current));

      // Monster proximity detection for HUD and sound
      if (onMonsterSight) {
        if (p >= 0.38 && p <= 0.54) {
          onMonsterSight('raven');
        } else if (p >= 0.70 && p <= 0.88) {
          onMonsterSight('rook');
        } else {
          onMonsterSight(null);
        }
      }

      // Camera position from spline
      const camPos = cameraCurve.getPointAt(p);
      const lookPos = lookAtCurve.getPointAt(p);

      if (cameraRef.current) {
        // Apply subtle mouse parallax to camera position
        cameraRef.current.position.x = camPos.x + mousePosRef.current.x * 0.8;
        cameraRef.current.position.y = camPos.y + mousePosRef.current.y * 0.5;
        cameraRef.current.position.z = camPos.z;

        // Apply camera sway
        const swayX = Math.sin(time * 0.0015) * 0.15;
        const swayY = Math.cos(time * 0.002) * 0.1;

        cameraRef.current.lookAt(
          lookPos.x + mousePosRef.current.x * 2.5 + swayX,
          lookPos.y + mousePosRef.current.y * 1.8 + swayY,
          lookPos.z
        );

        // Flashlight follows camera and aims at mouse target
        if (flashlightRef.current && flashlightTargetRef.current) {
          flashlightRef.current.position.copy(cameraRef.current.position);
          flashlightTargetRef.current.position.set(
            lookPos.x + mousePosRef.current.x * 12,
            lookPos.y + mousePosRef.current.y * 8,
            lookPos.z
          );
        }
      }

      // Animate Emerald Core Monolith
      if (emeraldCoreRef.current) {
        emeraldCoreRef.current.rotation.x += 0.012;
        emeraldCoreRef.current.rotation.y += 0.018;
        const pulse = 1 + Math.sin(time * 0.004) * 0.15;
        emeraldCoreRef.current.scale.set(pulse, pulse, pulse);
      }

      if (coreRingsRef.current) {
        coreRingsRef.current.rotation.x -= 0.008;
        coreRingsRef.current.rotation.y += 0.015;
        coreRingsRef.current.rotation.z += 0.005;
      }

      // Animate Raven Wing Twitch & Head
      if (ravenWingLeftRef.current && ravenWingRightRef.current) {
        const wingFlap = Math.sin(time * 0.003) * 0.12;
        ravenWingLeftRef.current.rotation.z = wingFlap;
        ravenWingRightRef.current.rotation.z = -wingFlap;
      }

      // Animate Rook Arms & Breathing
      if (rookArmLeftRef.current && rookArmRightRef.current) {
        const breathe = Math.sin(time * 0.002) * 0.08;
        rookArmLeftRef.current.rotation.x = breathe;
        rookArmRightRef.current.rotation.x = -breathe;
      }

      // Animate Toxic River Vertices
      if (toxicRiverRef.current) {
        const posAttr = toxicRiverRef.current.geometry.attributes.position;
        for (let i = 0; i < posAttr.count; i++) {
          const u = posAttr.getX(i);
          const v = posAttr.getY(i);
          posAttr.setZ(i, Math.sin(u * 0.5 + time * 0.003) * 0.3 + Math.cos(v * 0.8 + time * 0.002) * 0.2);
        }
        posAttr.needsUpdate = true;
      }

      // Animate Point Lights Flickering
      flickerLightsRef.current.forEach((light, idx) => {
        const flicker = 0.85 + Math.sin(time * 0.005 + idx * 1.7) * 0.15 + (Math.random() > 0.95 ? -0.25 : 0);
        light.intensity = flicker * (idx === 7 ? 8.0 : 3.0);
      });

      // Animate Floating Toxic Particles drifting upward
      if (particlesRef.current) {
        const pos = particlesRef.current.geometry.attributes.position;
        for (let i = 0; i < particleCount; i++) {
          let y = pos.getY(i);
          y += 0.035;
          if (y > 25) {
            y = -90; // wrap back to deep crypt
          }
          pos.setY(i, y);
          // subtle horizontal swirl
          pos.setX(i, pos.getX(i) + Math.sin(time * 0.001 + i) * 0.01);
        }
        pos.needsUpdate = true;
      }

      // Night Vision mode adjustment
      if (rendererRef.current && sceneRef.current) {
        if (nightVision) {
          sceneRef.current.fog = new THREE.FogExp2(0x240a0a, 0.045);
        } else {
          sceneRef.current.fog = new THREE.FogExp2(0x080202, 0.024);
        }
        rendererRef.current.render(sceneRef.current, cameraRef.current!);
      }
    };

    animFrameIdRef.current = requestAnimationFrame(animate);

    // Cleanup
    return () => {
      if (animFrameIdRef.current) {
        cancelAnimationFrame(animFrameIdRef.current);
      }
      window.removeEventListener('mousemove', handleMouseMove);
      resizeObserver.disconnect();
      if (rendererRef.current && rendererRef.current.domElement) {
        container.removeChild(rendererRef.current.domElement);
        rendererRef.current.dispose();
      }
    };
  }, []);

  // Update flashlight intensity when toggled
  useEffect(() => {
    if (flashlightRef.current) {
      flashlightRef.current.intensity = flashlightOn ? 4.8 : 0;
    }
  }, [flashlightOn]);

  if (!webGlSupported) {
    return (
      <div className="absolute inset-0 flex items-center justify-center bg-[#070202] text-red-400 p-8 text-center">
        <div>
          <h2 className="text-2xl font-bold font-cinzel mb-2">3D Acceleration Offline</h2>
          <p className="text-sm text-red-200/70 max-w-md">
            WebGL is not active in this preview environment. The 2D atmospheric narrative layers remain fully functional.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div
      ref={mountRef}
      className={`fixed inset-0 w-full h-full pointer-events-none transition-all duration-700 ${
        nightVision ? 'filter contrast-150 brightness-125 sepia hue-rotate-320' : ''
      }`}
      style={{ zIndex: 0 }}
    >
      {/* Subtle bottom HUD watermark */}
      <div className="absolute bottom-4 left-4 z-10 pointer-events-auto flex items-center gap-2 text-[10px] tracking-widest text-[#FF1E27]/50 uppercase font-mono-horror">
        <span className="inline-block w-2 h-2 rounded-full bg-[#FF1E27] animate-ping" />
        <span>3D ENGINE ACTIVE • {fps} FPS</span>
      </div>
    </div>
  );
};
