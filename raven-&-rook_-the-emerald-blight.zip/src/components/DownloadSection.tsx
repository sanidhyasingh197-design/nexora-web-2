import React, { useState } from 'react';
import { Download, Monitor, HardDrive, Sparkles, CheckCircle2, Copy, Check } from 'lucide-react';
import { SYSTEM_SPECS } from '../data/manorData';
import { horrorAudio } from '../utils/audio';
import confetti from 'canvas-confetti';

export const DownloadSection: React.FC = () => {
  const [downloadStarted, setDownloadStarted] = useState(false);
  const [downloadProgress, setDownloadProgress] = useState(0);
  const [copiedKey, setCopiedKey] = useState(false);
  const [showTrailerModal, setShowTrailerModal] = useState(false);
  const demoKey = 'BLIGHT-RVNK-ROOK-1889-ALPHA';

  const handleDownloadClick = () => {
    horrorAudio.playThunder();
    setDownloadStarted(true);
    setDownloadProgress(0);

    // Fire horror crimson confetti
    confetti({
      particleCount: 80,
      spread: 70,
      origin: { y: 0.7 },
      colors: ['#FF1E27', '#DC2626', '#B91C1C', '#ffffff'],
    });

    // Simulate installer progress
    const interval = window.setInterval(() => {
      setDownloadProgress((prev) => {
        if (prev >= 100) {
          window.clearInterval(interval);
          return 100;
        }
        return prev + 10;
      });
    }, 200);
  };

  const handleCopyKey = () => {
    navigator.clipboard.writeText(demoKey);
    setCopiedKey(true);
    horrorAudio.playToxicDrip();
    setTimeout(() => setCopiedKey(false), 2500);
  };

  return (
    <section className="relative z-20 min-h-screen flex flex-col justify-center items-center px-4 sm:px-8 md:px-16 py-24 text-center max-w-5xl mx-auto font-serif">
      {/* Glow Backdrop & Bottom Crimson Gradient */}
      <div className="absolute inset-0 bg-gradient-to-t from-black via-[#020202] to-transparent pointer-events-none -z-10" />
      <div className="absolute bottom-0 w-full h-72 bg-gradient-to-t from-[#2b0606] to-transparent opacity-40 pointer-events-none -z-10" />

      {/* Top Blight Monolith Badge */}
      <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-black/80 border border-[#FF1E27]/50 text-[#FF1E27] text-xs font-mono-horror tracking-widest uppercase mb-6 shadow-[0_0_15px_rgba(255,30,39,0.2)]">
        <Sparkles size={14} className="text-[#FF1E27] animate-spin" />
        CHAPTER FINALIS • THE MONOLITH CRUCIBLE REACHED
      </div>

      {/* Hero Headline */}
      <h2 className="text-4xl sm:text-6xl md:text-7xl font-black font-serif-display tracking-widest text-[#FF1E27] drop-shadow-[0_0_15px_rgba(255,30,39,0.5)] uppercase max-w-4xl leading-tight">
        ENTER THE <br />
        CRIMSON NIGHTMARE
      </h2>

      {/* ========================================================= */}
      {/* THE IMMERSIVE UI THEME SIGNATURE DOWNLOAD BUTTON */}
      {/* ========================================================= */}
      <div className="my-10 w-full max-w-lg">
        <button
          id="massive-pulsating-download-btn"
          onClick={handleDownloadClick}
          className="relative group w-full cursor-pointer block"
        >
          {/* Outer Blur Halo */}
          <div className="absolute -inset-1 bg-[#FF1E27] rounded-sm blur opacity-25 group-hover:opacity-75 transition-opacity" />
          
          {/* Main Button Container */}
          <div className="relative px-8 sm:px-12 py-5 sm:py-6 bg-black border-2 border-[#FF1E27] text-[#FF1E27] text-2xl sm:text-3xl font-bold tracking-[0.2em] uppercase shadow-[0_0_30px_rgba(255,30,39,0.4)] flex items-center justify-center gap-4 transition-transform group-hover:scale-[1.02] group-active:scale-[0.99]">
            <Download size={28} className="animate-bounce" />
            <span className="font-serif-display">DOWNLOAD GAME</span>
          </div>
        </button>

        {/* Flanked Platform Hairline Divider from Immersive UI Theme */}
        <div className="mt-6 flex items-center justify-center gap-4 text-zinc-600">
          <div className="w-20 sm:w-32 h-[1px] bg-zinc-800" />
          <span className="text-xs uppercase tracking-widest text-zinc-400 font-mono-horror">
            PC / MACOS / VR / CONSOLES
          </span>
          <div className="w-20 sm:w-32 h-[1px] bg-zinc-800" />
        </div>

        <p className="mt-3 text-[11px] text-[#FF1E27]/80 font-mono-horror tracking-wider">
          ★ FREE PLAYTEST DEMO • v0.9.4 • UNREAL ENGINE 5.5 • 18.4 GB
        </p>
      </div>

      {/* Download Simulator / Modal Feedback if Triggered */}
      {downloadStarted && (
        <div className="w-full max-w-xl p-6 bg-black/80 border-2 border-[#FF1E27] mb-8 animate-fadeIn text-left  shadow-[0_0_30px_rgba(255,30,39,0.25)]">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2 text-[#FF1E27] font-bold text-sm tracking-wider uppercase">
              <HardDrive size={18} />
              <span>
                {downloadProgress === 100 ? 'DOWNLOAD COMPLETE!' : 'PREPARING BLIGHTED PACKAGES...'}
              </span>
            </div>
            <span className="text-sm font-mono-horror text-white font-bold">
              {downloadProgress}%
            </span>
          </div>

          {/* Progress bar */}
          <div className="w-full h-2.5 bg-black rounded-full overflow-hidden border border-[#FF1E27]/40 mb-4">
            <div
              className="h-full bg-gradient-to-r from-[#FF1E27] to-white transition-all duration-200"
              style={{ width: `${downloadProgress}%` }}
            />
          </div>

          {downloadProgress === 100 ? (
            <div className="space-y-3 pt-2">
              <div className="flex items-center gap-2 text-zinc-300 text-xs font-mono-horror">
                <CheckCircle2 size={16} className="text-[#FF1E27]" />
                <span>Installer verified: RavenRook_CrimsonBlight_Demo.exe</span>
              </div>
              {/* Access Key */}
              <div className="p-3 bg-black/90 border border-[#FF1E27]/40 flex items-center justify-between">
                <div>
                  <div className="text-[10px] text-zinc-400 font-mono-horror">
                    STEAM PLAYTEST ACCESS KEY
                  </div>
                  <div className="text-xs sm:text-sm font-mono-horror text-white font-bold tracking-wider">
                    {demoKey}
                  </div>
                </div>
                <button
                  onClick={handleCopyKey}
                  className="px-3 py-1.5 bg-black border border-[#FF1E27]/60 text-[#FF1E27] hover:bg-[#FF1E27] hover:text-black text-xs font-mono-horror flex items-center gap-1 cursor-pointer transition-all uppercase"
                >
                  {copiedKey ? <Check size={14} /> : <Copy size={14} />}
                  <span>{copiedKey ? 'COPIED' : 'COPY'}</span>
                </button>
              </div>
            </div>
          ) : (
            <p className="text-xs text-zinc-400 font-mono-horror">
              Allocating direct storage block... Initializing anti-blight telemetry.
            </p>
          )}
        </div>
      )}

      {/* System Requirements Grid */}
      <div className="w-full max-w-4xl border-l border-r border-[#FF1E27]/30 p-6 md:p-8 text-left bg-black/60 ">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Minimum */}
          <div className="space-y-2.5 p-4 bg-black/50 border border-zinc-800">
            <div className="text-xs font-mono-horror text-[#FF1E27] font-bold uppercase tracking-wider">
              MINIMUM SPECIFICATIONS (1080p 30fps)
            </div>
            <div className="text-xs text-zinc-300 space-y-1.5">
              <div><strong className="text-zinc-100">OS:</strong> {SYSTEM_SPECS.minimum.os}</div>
              <div><strong className="text-zinc-100">Processor:</strong> {SYSTEM_SPECS.minimum.processor}</div>
              <div><strong className="text-zinc-100">Memory:</strong> {SYSTEM_SPECS.minimum.memory}</div>
              <div><strong className="text-zinc-100">Graphics:</strong> {SYSTEM_SPECS.minimum.graphics}</div>
              <div><strong className="text-zinc-100">Storage:</strong> {SYSTEM_SPECS.minimum.storage}</div>
            </div>
          </div>

          {/* Recommended */}
          <div className="space-y-2.5 p-4 bg-black/70 border border-[#FF1E27]/40">
            <div className="text-xs font-mono-horror text-[#FF1E27] font-bold uppercase tracking-wider flex items-center gap-1.5">
              <Sparkles size={14} className="text-[#FF1E27]" />
              RECOMMENDED SPECIFICATIONS (1440p / 4K 60fps)
            </div>
            <div className="text-xs text-zinc-300 space-y-1.5">
              <div><strong className="text-zinc-100">OS:</strong> {SYSTEM_SPECS.recommended.os}</div>
              <div><strong className="text-zinc-100">Processor:</strong> {SYSTEM_SPECS.recommended.processor}</div>
              <div><strong className="text-zinc-100">Memory:</strong> {SYSTEM_SPECS.recommended.memory}</div>
              <div><strong className="text-zinc-100">Graphics:</strong> {SYSTEM_SPECS.recommended.graphics}</div>
              <div><strong className="text-zinc-100">Storage:</strong> {SYSTEM_SPECS.recommended.storage}</div>
            </div>
          </div>
        </div>
      </div>

      {/* Footer Details */}
      <footer className="mt-16 text-center text-xs text-zinc-500 font-mono-horror space-y-2">
        <p>© 1889 / 2026 BLACKWOOD INTERACTIVE STUDIOS. ALL RIGHTS RESERVED.</p>
        <p className="text-[10px] text-zinc-600 uppercase tracking-wider">
          RAVEN & ROOK IS A TRADEMARK OF BLACKWOOD INTERACTIVE. BUILT WITH THREE.JS VERTICAL CAMERA INTERPOLATION.
        </p>
      </footer>
    </section>
  );
};
