import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { ARTIFACTS } from '../data/manorData';
import { Artifact } from '../types';
import { X, ShieldAlert, Sparkles, Flame, Rotate3D, Info } from 'lucide-react';
import { horrorAudio } from '../utils/audio';

interface ArtifactInspectorModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialArtifactId?: string;
}

export const ArtifactInspectorModal: React.FC<ArtifactInspectorModalProps> = ({
  isOpen,
  onClose,
  initialArtifactId,
}) => {
  const [selectedArtifact, setSelectedArtifact] = useState<Artifact>(
    ARTIFACTS.find((a) => a.id === initialArtifactId) || ARTIFACTS[0]
  );
  const canvasRef = useRef<HTMLDivElement>(null);
  const isDraggingRef = useRef(false);
  const previousMousePositionRef = useRef({ x: 0, y: 0 });
  const meshGroupRef = useRef<THREE.Group | null>(null);

  useEffect(() => {
    if (initialArtifactId) {
      const found = ARTIFACTS.find((a) => a.id === initialArtifactId);
      if (found) setSelectedArtifact(found);
    }
  }, [initialArtifactId]);

  useEffect(() => {
    if (!isOpen || !canvasRef.current) return;
    const container = canvasRef.current;

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(45, container.clientWidth / container.clientHeight, 0.1, 50);
    camera.position.set(0, 0, 8);

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    // Lights
    const ambient = new THREE.AmbientLight(0x1f0a0a, 1.2);
    scene.add(ambient);

    const keyLight = new THREE.PointLight(0xFF1E27, 3.5, 20);
    keyLight.position.set(4, 5, 5);
    scene.add(keyLight);

    const backLight = new THREE.PointLight(0x991b1b, 2.0, 20);
    backLight.position.set(-4, -3, -3);
    scene.add(backLight);

    const group = new THREE.Group();
    meshGroupRef.current = group;
    scene.add(group);

    // Build geometry based on artifact type
    const toxicMat = new THREE.MeshStandardMaterial({
      color: 0xFF1E27,
      emissive: 0xFF1E27,
      emissiveIntensity: 0.8,
      roughness: 0.2,
      metalness: 0.3,
      transparent: true,
      opacity: 0.85,
    });

    const ironMat = new THREE.MeshStandardMaterial({
      color: 0x2a2222,
      roughness: 0.6,
      metalness: 0.8,
    });

    if (selectedArtifact.geometryType === 'vial') {
      // Glass vial
      const bottleGeo = new THREE.CylinderGeometry(1.2, 1.4, 4.2, 16);
      const bottleMesh = new THREE.Mesh(bottleGeo, toxicMat);
      group.add(bottleMesh);

      // Cork
      const corkGeo = new THREE.CylinderGeometry(0.7, 0.7, 0.8, 12);
      const corkMesh = new THREE.Mesh(corkGeo, ironMat);
      corkMesh.position.y = 2.4;
      group.add(corkMesh);

      // Metal bands
      const band1 = new THREE.Mesh(new THREE.TorusGeometry(1.4, 0.1, 8, 24), ironMat);
      band1.rotation.x = Math.PI / 2;
      band1.position.y = 1.0;
      const band2 = new THREE.Mesh(new THREE.TorusGeometry(1.45, 0.1, 8, 24), ironMat);
      band2.rotation.x = Math.PI / 2;
      band2.position.y = -1.0;
      group.add(band1, band2);
    } else if (selectedArtifact.geometryType === 'mask') {
      // Plague doctor mask beak
      const headGeo = new THREE.SphereGeometry(1.6, 16, 16);
      const headMesh = new THREE.Mesh(headGeo, ironMat);
      group.add(headMesh);

      const beakGeo = new THREE.ConeGeometry(0.8, 3.8, 8);
      const beakMesh = new THREE.Mesh(beakGeo, toxicMat);
      beakMesh.rotation.x = Math.PI / 2;
      beakMesh.position.set(0, -0.4, 2.2);
      group.add(beakMesh);
    } else if (selectedArtifact.geometryType === 'chitin') {
      // Massive fractured iron shackle & spiked core
      const core = new THREE.Mesh(new THREE.DodecahedronGeometry(1.8, 1), toxicMat);
      group.add(core);

      const ring = new THREE.Mesh(new THREE.TorusGeometry(2.4, 0.45, 8, 24), ironMat);
      ring.rotation.x = Math.PI / 3;
      group.add(ring);

      for (let i = 0; i < 6; i++) {
        const spike = new THREE.Mesh(new THREE.ConeGeometry(0.4, 1.4, 6), ironMat);
        spike.position.set(
          Math.sin((i * Math.PI) / 3) * 2.2,
          Math.cos((i * Math.PI) / 3) * 2.2,
          0
        );
        spike.rotation.z = -(i * Math.PI) / 3;
        group.add(spike);
      }
    } else {
      // Crucible / Grimoire
      const book = new THREE.Mesh(new THREE.BoxGeometry(2.8, 3.8, 0.9), ironMat);
      group.add(book);

      const rune = new THREE.Mesh(new THREE.TorusGeometry(0.8, 0.1, 6, 16), toxicMat);
      rune.position.z = 0.5;
      group.add(rune);
    }

    let animId: number;
    const animate = () => {
      animId = requestAnimationFrame(animate);
      if (!isDraggingRef.current && group) {
        group.rotation.y += 0.01;
        group.rotation.x = Math.sin(Date.now() * 0.001) * 0.15;
      }
      renderer.render(scene, camera);
    };
    animate();

    // Mouse drag rotation
    const onMouseDown = (e: MouseEvent) => {
      isDraggingRef.current = true;
      previousMousePositionRef.current = { x: e.clientX, y: e.clientY };
    };

    const onMouseMove = (e: MouseEvent) => {
      if (!isDraggingRef.current || !meshGroupRef.current) return;
      const deltaX = e.clientX - previousMousePositionRef.current.x;
      const deltaY = e.clientY - previousMousePositionRef.current.y;
      meshGroupRef.current.rotation.y += deltaX * 0.01;
      meshGroupRef.current.rotation.x += deltaY * 0.01;
      previousMousePositionRef.current = { x: e.clientX, y: e.clientY };
    };

    const onMouseUp = () => {
      isDraggingRef.current = false;
    };

    container.addEventListener('mousedown', onMouseDown);
    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('mouseup', onMouseUp);

    return () => {
      cancelAnimationFrame(animId);
      container.removeEventListener('mousedown', onMouseDown);
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mouseup', onMouseUp);
      renderer.dispose();
    };
  }, [isOpen, selectedArtifact]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fadeIn font-serif">
      <div className="relative w-full max-w-4xl bg-[#020202] border border-[#FF1E27]/40 p-6 md:p-8 text-[#f3dada] shadow-[0_0_50px_rgba(255,30,39,0.15)]">
        {/* Close Button */}
        <button
          id="close-artifact-modal-btn"
          onClick={() => {
            horrorAudio.playToxicDrip();
            onClose();
          }}
          className="absolute top-4 right-4 p-2 bg-black border border-[#FF1E27]/40 text-[#FF1E27] hover:bg-[#FF1E27] hover:text-black transition-all z-20 cursor-pointer"
        >
          <X size={18} />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3 mb-6 pb-4 border-b border-zinc-800">
          <Sparkles className="text-[#FF1E27] animate-pulse" size={22} />
          <div>
            <h2 className="text-xl md:text-2xl font-bold font-serif-display text-white tracking-widest uppercase">
              BLIGHTED RELIC ARCHIVE
            </h2>
            <p className="text-xs text-[#FF1E27]/80 font-mono-horror tracking-wider uppercase">
              ESTATE EVIDENCE • RECOVERED FROM THE DEEP CRYPT
            </p>
          </div>
        </div>

        {/* Artifact Selector Chips */}
        <div className="flex flex-wrap gap-2 mb-6">
          {ARTIFACTS.map((art) => (
            <button
              key={art.id}
              id={`artifact-chip-${art.id}`}
              onClick={() => {
                horrorAudio.playToxicDrip();
                setSelectedArtifact(art);
              }}
              className={`px-4 py-2 text-xs md:text-sm transition-all cursor-pointer flex items-center gap-2 border uppercase tracking-wider font-mono-horror ${
                selectedArtifact.id === art.id
                  ? 'bg-black border-[#FF1E27] text-[#FF1E27] shadow-[0_0_15px_rgba(255,30,39,0.3)]'
                  : 'bg-black/50 border-zinc-800 text-zinc-400 hover:border-[#FF1E27]/50 hover:text-zinc-200'
              }`}
            >
              <Rotate3D size={14} className={selectedArtifact.id === art.id ? 'text-[#FF1E27]' : ''} />
              {art.name.split(' ')[0]} {art.name.split(' ')[1]}
            </button>
          ))}
        </div>

        {/* Content Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
          {/* 3D Interactive Canvas */}
          <div className="relative h-64 md:h-80 w-full bg-black border border-[#FF1E27]/30 overflow-hidden flex items-center justify-center cursor-grab active:cursor-grabbing">
            <div ref={canvasRef} className="w-full h-full" />
            <div className="absolute bottom-3 left-3 text-[10px] text-[#FF1E27]/80 font-mono-horror tracking-wider flex items-center gap-1 pointer-events-none uppercase">
              <Rotate3D size={12} /> DRAG TO ROTATE 3D SPECIMEN
            </div>
            <div className="absolute top-3 right-3 px-2 py-0.5 bg-black text-[9px] text-[#FF1E27] font-mono-horror border border-[#FF1E27]/50 tracking-widest uppercase">
              3D RELIC
            </div>
          </div>

          {/* Lore & Details */}
          <div className="space-y-4">
            <div>
              <span className="text-xs uppercase tracking-widest font-mono-horror text-[#FF1E27]/70">
                {selectedArtifact.origin}
              </span>
              <h3 className="text-2xl font-bold font-serif-display text-white mt-1 uppercase tracking-wide">
                {selectedArtifact.name}
              </h3>
            </div>

            <p className="text-sm text-zinc-300 leading-relaxed font-light">
              {selectedArtifact.description}
            </p>

            <div className="p-3 bg-black border-l-2 border-[#FF1E27] text-xs italic text-zinc-300">
              "{selectedArtifact.loreFragment}"
            </div>

            <div className="grid grid-cols-2 gap-3 pt-2">
              <div className="p-3 bg-black border border-zinc-800">
                <div className="flex items-center gap-1.5 text-[11px] text-[#FF1E27] font-mono-horror uppercase">
                  <ShieldAlert size={14} /> TOXICITY INDEX
                </div>
                <div className="text-base font-bold text-white font-mono-horror mt-1">
                  {selectedArtifact.toxicRating}
                </div>
              </div>

              <div className="p-3 bg-black border border-zinc-800">
                <div className="flex items-center gap-1.5 text-[11px] text-[#FF1E27] font-mono-horror uppercase">
                  <Flame size={14} /> CURSE STATUS
                </div>
                <div className="text-base font-bold text-[#FF1E27] font-mono-horror mt-1">
                  ACTIVE & RADIANT
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
