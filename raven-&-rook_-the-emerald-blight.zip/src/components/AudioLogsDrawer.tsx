import React, { useState } from 'react';
import { AUDIO_LOGS } from '../data/manorData';
import { AudioLog } from '../types';
import { X, Play, Pause, Radio, Calendar, User, Volume2 } from 'lucide-react';
import { horrorAudio } from '../utils/audio';

interface AudioLogsDrawerProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AudioLogsDrawer: React.FC<AudioLogsDrawerProps> = ({ isOpen, onClose }) => {
  const [activeLog, setActiveLog] = useState<AudioLog>(AUDIO_LOGS[0]);
  const [isPlaying, setIsPlaying] = useState(false);

  const handleTogglePlay = (log: AudioLog) => {
    if (activeLog.id === log.id && isPlaying) {
      setIsPlaying(false);
    } else {
      setActiveLog(log);
      setIsPlaying(true);
      horrorAudio.playToxicDrip();
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-end p-4 sm:p-6 bg-black/85 backdrop-blur-sm animate-fadeIn font-serif">
      <div className="relative w-full max-w-lg h-[90vh] bg-[#020202] border border-[#FF1E27]/40 p-6 flex flex-col text-[#f3dada] shadow-[0_0_40px_rgba(255,30,39,0.15)]">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-zinc-800">
          <div className="flex items-center gap-2 text-[#FF1E27]">
            <Radio className="animate-pulse" size={20} />
            <h3 className="font-serif-display font-bold text-lg text-white uppercase tracking-wider">
              RECOVERED DISPATCH CASSETTES
            </h3>
          </div>
          <button
            id="close-audio-logs-btn"
            onClick={onClose}
            className="p-1.5 bg-black border border-[#FF1E27]/40 text-[#FF1E27] hover:bg-[#FF1E27] hover:text-black cursor-pointer transition-all"
          >
            <X size={18} />
          </button>
        </div>

        {/* Cassette List */}
        <div className="space-y-3 my-4 overflow-y-auto pr-1">
          {AUDIO_LOGS.map((log) => {
            const isCurrent = activeLog.id === log.id;
            return (
              <div
                key={log.id}
                onClick={() => handleTogglePlay(log)}
                className={`p-4 border transition-all cursor-pointer ${
                  isCurrent
                    ? 'bg-black border-[#FF1E27] shadow-[0_0_15px_rgba(255,30,39,0.25)]'
                    : 'bg-black/40 border-zinc-800 hover:border-[#FF1E27]/40'
                }`}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-xs font-mono-horror text-[#FF1E27] font-bold uppercase tracking-wider">
                    {log.title}
                  </span>
                  <span className="text-[11px] font-mono-horror text-zinc-500">
                    {log.duration}
                  </span>
                </div>

                <div className="flex items-center gap-4 text-[11px] text-zinc-400 font-mono-horror mb-2">
                  <span className="flex items-center gap-1">
                    <Calendar size={12} /> {log.date}
                  </span>
                  <span className="flex items-center gap-1">
                    <User size={12} /> {log.speaker}
                  </span>
                </div>

                {/* Animated Audio Bars when active & playing */}
                {isCurrent && isPlaying && (
                  <div className="flex items-center gap-1 py-1">
                    {[40, 75, 25, 90, 50, 80, 30, 60, 95, 45].map((h, i) => (
                      <div
                        key={i}
                        className="w-1.5 bg-[#FF1E27] animate-pulse"
                        style={{
                          height: `${(h / 100) * 20}px`,
                          animationDelay: `${i * 0.1}s`,
                        }}
                      />
                    ))}
                    <span className="text-[10px] text-[#FF1E27] font-mono-horror ml-2 uppercase tracking-widest">
                      PLAYING PHONOGRAPH TAPE...
                    </span>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Selected Transcript Detail */}
        <div className="mt-auto p-4 bg-black border border-zinc-800 space-y-2">
          <div className="text-[11px] font-mono-horror text-[#FF1E27] uppercase tracking-widest flex items-center gap-1.5">
            <Volume2 size={14} /> TRANSCRIPT • {activeLog.speaker}
          </div>
          <p className="text-xs text-zinc-300 italic leading-relaxed font-light">
            "{activeLog.transcript}"
          </p>
        </div>
      </div>
    </div>
  );
};
