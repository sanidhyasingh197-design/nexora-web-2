import React, { useState } from 'react';
import { Volume2, VolumeX, Eye, EyeOff, Book } from 'lucide-react';
import { MANOR_CHAPTERS } from '../data/manorData';
import { horrorAudio } from '../utils/audio';

interface NavigationHeaderProps {
  scrollProgress: number;
  nightVision: boolean;
  hasNewLog: boolean;
  onToggleNightVision: () => void;
  onJumpToChapter: (progress: number) => void;
  onOpenJournal: () => void;
}

export const NavigationHeader: React.FC<NavigationHeaderProps> = ({
  scrollProgress,
  nightVision,
  hasNewLog,
  onToggleNightVision,
  onJumpToChapter,
  onOpenJournal,
}) => {
  const [isMuted, setIsMuted] = useState(true);
  const [showChapters, setShowChapters] = useState(false);

  const handleToggleSound = () => {
    const muted = horrorAudio.toggleMute();
    setIsMuted(muted);
    if (!muted) {
      horrorAudio.playToxicDrip();
    }
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-40 bg-[#020202]/85  border-b border-[#FF1E27]/20 px-4 md:px-8 py-3 transition-all font-serif">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        {/* Brand Logo & Title */}
        <div className="flex items-center gap-3">
          <div>
            <h1 className="text-sm md:text-base font-serif-display font-black tracking-widest text-white leading-none flex items-center gap-2">
              ECHO OF DARKNESS
              <span className="hidden sm:inline-block px-1.5 py-0.2 bg-black border border-[#FF1E27]/60 text-[9px] font-mono-horror text-[#FF1E27] tracking-widest uppercase">
                DEMO v0.9
              </span>
            </h1>
            <p className="text-[10px] md:text-[11px] font-mono-horror tracking-widest text-[#FF1E27]/80 mt-0.5 uppercase">
              THE CRIMSON BLIGHT
            </p>
          </div>
        </div>

        {/* Chapter Quick Jump (Desktop) */}
        <div className="hidden lg:flex items-center gap-1 bg-black/80 px-2 py-1 border border-zinc-800">
          {MANOR_CHAPTERS.map((chap) => {
            const isActive =
              Math.abs(scrollProgress - chap.scrollProgress) < 0.18 ||
              (chap.scrollProgress === 0 && scrollProgress < 0.2);
            return (
              <button
                key={chap.id}
                id={`nav-chapter-${chap.id}`}
                onClick={() => {
                  horrorAudio.playToxicDrip();
                  onJumpToChapter(chap.scrollProgress);
                }}
                className={`px-3 py-1 text-xs transition-all cursor-pointer tracking-wider font-mono-horror uppercase ${
                  isActive
                    ? 'bg-black text-[#FF1E27] border border-[#FF1E27] shadow-[0_0_10px_rgba(255,30,39,0.3)]'
                    : 'text-zinc-400 hover:text-[#FF1E27] hover:bg-zinc-900/50'
                }`}
              >
                {chap.number}. {chap.shortTitle}
              </button>
            );
          })}
        </div>

        {/* Interactive Controls & Modals */}
        <div className="flex items-center gap-2 md:gap-3">
          {/* Journal Log */}
          <button
            onClick={() => {
              horrorAudio.playToxicDrip();
              onOpenJournal();
            }}
            className="relative p-1.5 bg-black border border-zinc-800 text-zinc-500 hover:text-[#FF1E27] hover:border-[#FF1E27]/50 transition-all cursor-pointer"
            title="Field Journal"
          >
            <Book size={14} />
            {hasNewLog && (
              <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-[#FF1E27] rounded-full animate-pulse shadow-[0_0_8px_#FF1E27]" />
            )}
          </button>

          {/* Night Vision / Sanity Sensor */}
          <button
            id="nav-nightvision-btn"
            onClick={() => {
              horrorAudio.playToxicDrip();
              onToggleNightVision();
            }}
            title="Night Vision Filter"
            className={`p-1.5 border transition-all cursor-pointer ${
              nightVision
                ? 'bg-black border-[#FF1E27] text-[#FF1E27] shadow-[0_0_12px_rgba(255,30,39,0.3)]'
                : 'bg-black border-zinc-800 text-zinc-500 hover:text-[#FF1E27]'
            }`}
          >
            {nightVision ? <Eye size={14} className="text-[#FF1E27]" /> : <EyeOff size={14} />}
          </button>

          {/* Sound & Audio Synthesizer */}
          <div className="flex items-center gap-1.5 bg-black border border-zinc-800 px-2 py-1">
            <button
              id="nav-audio-mute-btn"
              onClick={handleToggleSound}
              title={isMuted ? 'Enable Procedural Horror Audio' : 'Mute Audio'}
              className={`p-0.5 cursor-pointer transition-colors ${
                isMuted ? 'text-zinc-600 hover:text-zinc-400' : 'text-[#FF1E27] hover:text-white'
              }`}
            >
              {isMuted ? <VolumeX size={14} /> : <Volume2 size={14} />}
            </button>
          </div>


        </div>
      </div>
    </header>
  );
};
