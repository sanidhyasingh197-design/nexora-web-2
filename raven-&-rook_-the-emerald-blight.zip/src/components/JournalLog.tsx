import React from 'react';
import { X, Book, Lock, AlertTriangle } from 'lucide-react';
import { horrorAudio } from '../utils/audio';

export interface JournalEntry {
  id: string;
  title: string;
  content: string;
  unlockedAtProgress: number;
}

export const JOURNAL_ENTRIES: JournalEntry[] = [
  {
    id: 'entry-1',
    title: 'Chapter 1: Find',
    content: 'A biological curse that consumes the flesh and twists the mind. It started in the greenhouse, but its roots now dig into the very foundations of the manor.',
    unlockedAtProgress: 0.0,
  },
  {
    id: 'entry-2',
    title: "Raven's Anatomy",
    content: 'Subject shows highly mutated vocal cords capable of mimicking human speech. Blind, but extremely sensitive to sound and light. Weakness: Crimson Nightshade extract.',
    unlockedAtProgress: 0.35,
  },
  {
    id: 'entry-3',
    title: "Rook's Mutation",
    content: 'Bone density increased by 400%. The subject drags massive iron shackles, unable to maneuver swiftly. Highly destructive in a straight line. Weakness: Calcified Bone Dust.',
    unlockedAtProgress: 0.70,
  },
];

interface JournalLogProps {
  isOpen: boolean;
  onClose: () => void;
  unlockedLogs: string[];
}

export const JournalLog: React.FC<JournalLogProps> = ({ isOpen, onClose, unlockedLogs }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex justify-end pointer-events-auto font-serif">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-black/80  cursor-pointer transition-opacity"
        onClick={onClose}
      />
      
      {/* Drawer */}
      <div className="relative w-full max-w-md h-full bg-[#050505] border-l border-[#FF1E27]/30 shadow-[-10px_0_30px_rgba(0,0,0,0.8)] flex flex-col animate-in slide-in-from-right duration-300">
        
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-zinc-800 bg-black/50">
          <div className="flex items-center gap-3 text-[#FF1E27]">
            <Book size={20} className="stroke-[2.5]" />
            <h2 className="font-serif-display font-black tracking-widest uppercase text-lg">
              Field Journal
            </h2>
          </div>
          <button 
            onClick={() => {
              horrorAudio.playToxicDrip();
              onClose();
            }}
            className="text-zinc-500 hover:text-[#FF1E27] transition-colors p-2"
          >
            <X size={24} />
          </button>
        </div>

        {/* Content List */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6 scrollbar-thin scrollbar-thumb-zinc-800 scrollbar-track-transparent">
          <div className="flex items-center gap-2 mb-6">
            <AlertTriangle size={14} className="text-zinc-500" />
            <span className="text-xs font-mono-horror text-zinc-500 uppercase tracking-widest">
              Recovered Research Data
            </span>
          </div>

          {JOURNAL_ENTRIES.map((entry) => {
            const isUnlocked = unlockedLogs.includes(entry.id);
            
            return (
              <div 
                key={entry.id} 
                className={`p-5 border transition-all ${
                  isUnlocked 
                    ? 'border-[#FF1E27]/40 bg-black shadow-[inset_0_0_20px_rgba(255,30,39,0.05)]' 
                    : 'border-zinc-800/50 bg-[#0a0a0a]/50'
                }`}
              >
                <div className="flex items-center justify-between mb-3">
                  <h3 className={`font-bold uppercase tracking-wider text-sm ${
                    isUnlocked ? 'text-[#FF1E27]' : 'text-zinc-600'
                  }`}>
                    {isUnlocked ? entry.title : 'Encrypted Log'}
                  </h3>
                  {!isUnlocked && <Lock size={14} className="text-zinc-600" />}
                </div>
                
                <div className="relative">
                  <p className={`text-sm leading-relaxed ${
                    isUnlocked ? 'text-zinc-300' : 'text-zinc-600 font-mono-horror break-all opacity-40 select-none'
                  }`}>
                    {isUnlocked ? entry.content : entry.content.replace(/[a-zA-Z]/g, '█')}
                  </p>

                  {!isUnlocked && (
                    <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                      <span className="text-[#FF1E27] font-mono-horror tracking-[0.3em] font-bold border border-[#FF1E27]/50 bg-black/80 px-4 py-1.5 -rotate-6 shadow-[0_0_15px_rgba(255,30,39,0.3)]">
                        ENCRYPTED
                      </span>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
        
      </div>
    </div>
  );
};
