import React from 'react';
import { MONSTER_PROFILES } from '../data/manorData';
import { ShieldAlert, Sparkles, Feather, Skull, Flame, ChevronRight, Zap, Dna } from 'lucide-react';
import { horrorAudio } from '../utils/audio';

interface StoryOverlaysProps {
  onScrollToNext: () => void;
  onJumpToChapter?: (progress: number) => void;
}

export const StoryOverlays: React.FC<StoryOverlaysProps> = React.memo(({
  onScrollToNext,
  onJumpToChapter,
}) => {
  return (
    <div className="relative z-10 w-full font-serif">

      {/* ========================================================= */}
      {/* CHAPTER 1: THE ROTTING FOYER & ANCESTRAL PACT (Scroll: 0% - 25%) */}
      {/* ========================================================= */}
      <section className="min-h-screen flex flex-col justify-center items-center px-4 sm:px-8 md:px-16 pt-24 pb-20 max-w-5xl mx-auto text-center">
        <div className="space-y-6 w-full flex flex-col items-center">
          {/* Chapter Badge */}
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-black/80 border border-[#FF1E27]/40 text-[#FF1E27] text-xs font-mono-horror tracking-widest uppercase">
            <Sparkles size={13} /> CHAPTER 01 • THE HIDDEN RECIPE
          </div>

          {/* Main Title & Subtitle */}
          <div className="space-y-2">
            <h1 className="text-5xl sm:text-7xl md:text-8xl font-black tracking-widest text-[#FF1E27] drop-shadow-[0_0_15px_rgba(255,30,39,0.5)] uppercase font-serif-display leading-tight">
              ECHO OF DARKNESS
            </h1>
            <p className="text-sm sm:text-lg md:text-xl tracking-[0.4em] sm:tracking-[0.5em] font-light text-zinc-400 uppercase italic">
              Uncovering the Ancient Formula
            </p>
          </div>

          {/* Centered Lore Container */}
          <div className="w-full max-w-2xl border-l border-r border-[#FF1E27]/30 px-6 sm:px-12 py-6 sm:py-7 bg-black/40  my-3 text-center">
            <h2 className="text-lg sm:text-xl mb-2 text-zinc-100 uppercase tracking-tight font-bold">
              The Purifier's Quest
            </h2>
            <p className="text-sm sm:text-base leading-relaxed text-zinc-300">
              The manor is draped in shadows. To break the <b className="text-[#FF1E27] font-semibold">Crimson Blight</b>, you must search the rotting foyer and uncover the lost alchemical formula capable of curing the darkness.
            </p>
          </div>

          {/* Two Brother Comparison Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 w-full max-w-2xl text-left">
            <div 
              className="p-4 bg-black/60 border border-[#FF1E27]/30 transition-all space-y-1.5  flex flex-col justify-center text-left"
            >
              <div className="text-[#FF1E27] font-bold text-lg uppercase tracking-wider">
                OPTION 1
              </div>
              <p className="text-sm text-white leading-relaxed">
                be like everyone and die
              </p>
            </div>

            <button 
              onClick={() => {
                horrorAudio.playToxicDrip();
                onJumpToChapter?.(0.0);
              }}
              className="p-4 bg-black/60 border border-[#FF1E27]/30 hover:border-[#FF1E27]/70 hover:bg-[#FF1E27]/10 transition-all space-y-1.5  flex flex-col justify-center text-left cursor-pointer group"
            >
              <div className="text-[#FF1E27] font-bold text-lg uppercase tracking-wider group-hover:drop-shadow-[0_0_8px_rgba(255,30,39,0.8)] transition-all">
                OPTION 2
              </div>
              <p className="text-sm text-white leading-relaxed">
                cure the curse and escape
              </p>
            </button>
          </div>

          {/* Chapter Progression Division: Chapter 1, Chapter 2, Chapter 3 */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 w-full max-w-2xl pt-2 pb-1">
            <button
              onClick={() => onJumpToChapter?.(0.0)}
              className="flex flex-col items-center p-3 bg-black/60 border border-[#FF1E27]/40 hover:border-[#FF1E27] hover:bg-black/90 transition-all text-center group cursor-pointer"
            >
              <div className="w-px h-5 bg-gradient-to-b from-[#FF1E27] to-transparent mb-1" />
              <span className="text-[10px] font-mono-horror text-[#FF1E27] uppercase tracking-widest font-bold">
                CHAPTER 01
              </span>
              <span className="text-xs text-zinc-100 font-serif font-bold mt-1 group-hover:text-white transition-colors">
                FIND THE RECIPE
              </span>
              <span className="text-[10px] text-zinc-400 font-mono-horror mt-0.5">
                The Lost Formula
              </span>
            </button>

            <button
              onClick={() => onJumpToChapter?.(0.40)}
              className="flex flex-col items-center p-3 bg-black/60 border border-zinc-800 hover:border-[#FF1E27] hover:bg-black/90 transition-all text-center group cursor-pointer"
            >
              <div className="w-px h-5 bg-gradient-to-b from-[#FF1E27] to-transparent mb-1" />
              <span className="text-[10px] font-mono-horror text-[#FF1E27] uppercase tracking-widest font-bold">
                CHAPTER 02
              </span>
              <span className="text-xs text-zinc-100 font-serif font-bold mt-1 group-hover:text-white transition-colors">
                GATHER & BREW
              </span>
              <span className="text-[10px] text-zinc-400 font-mono-horror mt-0.5">
                Cursed Ingredients
              </span>
            </button>

            <button
              onClick={() => onJumpToChapter?.(0.78)}
              className="flex flex-col items-center p-3 bg-black/60 border border-zinc-800 hover:border-[#FF1E27] hover:bg-black/90 transition-all text-center group cursor-pointer"
            >
              <div className="w-px h-5 bg-gradient-to-b from-[#FF1E27] to-transparent mb-1" />
              <span className="text-[10px] font-mono-horror text-[#FF1E27] uppercase tracking-widest font-bold">
                CHAPTER 03
              </span>
              <span className="text-xs text-zinc-100 font-serif font-bold mt-1 group-hover:text-white transition-colors">
                REMOVE CURSE
              </span>
              <span className="text-[10px] text-zinc-400 font-mono-horror mt-0.5">
                Echo of Darkness
              </span>
            </button>
          </div>

          {/* Interactive CTAs */}
          <div className="flex flex-wrap items-center justify-center gap-4 pt-3">
            <button
              id="hero-begin-descent-btn"
              onClick={() => {
                horrorAudio.playToxicDrip();
                onScrollToNext();
              }}
              className="relative group cursor-pointer"
            >
              <div className="absolute -inset-0.5 bg-[#FF1E27] rounded-sm blur opacity-30 group-hover:opacity-80 transition-opacity" />
              <div className="relative px-7 py-3 bg-black border border-[#FF1E27] text-[#FF1E27] text-sm font-bold tracking-[0.2em] uppercase shadow-[0_0_20px_rgba(255,30,39,0.3)] hover:bg-[#FF1E27] hover:text-black transition-all flex items-center gap-2">
                <span>BEGIN 3D DESCENT</span>
                <ChevronRight size={16} />
              </div>
            </button>
          </div>
        </div>
      </section>

      {/* ========================================================= */}
      {/* CHAPTER 2: THE SHADOW RAFTERS — RAVEN (Scroll: 35% - 60%) */}
      {/* ========================================================= */}
      <section className="min-h-screen flex flex-col justify-center px-4 sm:px-8 md:px-16 py-24 max-w-6xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          <div className="lg:col-start-4 lg:col-span-9 space-y-6">
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-black/80 border border-[#FF1E27]/40 text-[#FF1E27] text-xs font-mono-horror uppercase tracking-widest">
              <Feather size={14} /> CHAPTER 02 • GATHER & BREW (THE RAFTERS)
            </div>

            <h2 className="text-3xl sm:text-5xl font-black font-serif-display text-white uppercase tracking-wider leading-tight">
              RAVEN <br />
              <span className="text-[#FF1E27] text-poison-glow">THE SHADOW GUARDIAN</span>
            </h2>

            <div className="relative border-l border-r border-[#FF1E27]/30 px-6 sm:px-8 py-4 bg-black/40 ">
              <p className="text-sm sm:text-base text-zinc-500 leading-relaxed font-mono-horror opacity-40 select-none break-all">
                {MONSTER_PROFILES.raven.lore.replace(/[a-zA-Z]/g, '█')}
              </p>
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                <span className="text-[#FF1E27] font-mono-horror tracking-[0.3em] font-bold border border-[#FF1E27]/50 bg-black/80 px-4 py-1.5 -rotate-6 shadow-[0_0_15px_rgba(255,30,39,0.3)]">
                  ENCRYPTED
                </span>
              </div>
            </div>

            {/* Combat & Behavioral Dossier */}
            <div className="relative space-y-3 p-6 bg-black/60 border border-[#FF1E27]/30  overflow-hidden">
              <div className="opacity-40 select-none pointer-events-none grayscale">
                <div className="flex items-center justify-between border-b border-zinc-800 pb-2.5">
                  <span className="text-xs font-mono-horror text-[#FF1E27] flex items-center gap-1.5 uppercase tracking-wider">
                    <ShieldAlert size={14} /> {'UNKNOWN'}
                  </span>
                  <span className="text-xs font-mono-horror text-zinc-400">
                    HEIGHT: {'██████'}
                  </span>
                </div>

                <div className="space-y-2 pt-1 font-mono-horror">
                  {MONSTER_PROFILES.raven.traits.map((trait, idx) => (
                    <div key={idx} className="flex items-start gap-2 text-xs text-zinc-500">
                      <span className="text-[#FF1E27] font-bold">•</span>
                      <span className="break-all">{trait.replace(/[a-zA-Z]/g, '█')}</span>
                    </div>
                  ))}
                </div>

                {/* Gameplay Mechanics Grid for Raven's Domain */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-3 border-t border-zinc-800/80">
                  <div className="p-3 bg-black/40 border border-[#FF1E27]/30 hover:border-[#FF1E27]/60 transition-colors space-y-1">
                    <div className="flex items-center gap-1.5 text-[#FF1E27] font-mono-horror text-xs font-bold uppercase">
                      <Feather size={13} /> INGREDIENT 01: ██████████
                    </div>
                    <p className="text-[11px] text-zinc-500 leading-relaxed font-mono-horror break-all">
                      {"A highly volatile botanical growing only in the highest, darkest rafters. Raven fiercely guards this rare bloom.".replace(/[a-zA-Z]/g, '█')}
                    </p>
                  </div>

                  <div className="p-3 bg-black/40 border border-zinc-900 hover:border-zinc-700 transition-colors space-y-1">
                    <div className="flex items-center gap-1.5 text-zinc-300 font-mono-horror text-xs font-bold uppercase">
                      <Flame size={13} /> INGREDIENT 02: ██████████
                    </div>
                    <p className="text-[11px] text-zinc-500 leading-relaxed font-mono-horror break-all">
                      {"Requires finding an uncorrupted vein of the original serum deep within the laboratory ducts.".replace(/[a-zA-Z]/g, '█')}
                    </p>
                  </div>
                </div>
              </div>
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-10">
                <span className="text-[#FF1E27] font-mono-horror tracking-[0.3em] font-bold border border-[#FF1E27]/50 bg-black/80 px-4 py-1.5 rotate-3 shadow-[0_0_15px_rgba(255,30,39,0.3)]">
                  ENCRYPTED
                </span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ========================================================= */}
      {/* CHAPTER 3: THE COLOSSUS SANCTUM — ROOK (Scroll: 70% - 92%) */}
      {/* ========================================================= */}
      <section className="min-h-screen flex flex-col justify-center px-4 sm:px-8 md:px-16 py-24 max-w-6xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          <div className="lg:col-span-9 space-y-6">
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-black/80 border border-[#FF1E27]/40 text-[#FF1E27] text-xs font-mono-horror uppercase tracking-widest">
              <Dna size={14} /> CHAPTER 03 • THE CURE (THE SANCTUM)
            </div>

            <h2 className="text-3xl sm:text-5xl font-black font-serif-display text-white uppercase tracking-wider leading-tight">
              ROOK <br />
              <span className="text-[#FF1E27] text-poison-glow">THE ABYSSAL WARDEN</span>
            </h2>

            <div className="relative border-l border-r border-[#FF1E27]/30 px-6 sm:px-8 py-4 bg-black/40 ">
              <p className="text-sm sm:text-base text-zinc-500 leading-relaxed font-mono-horror opacity-40 select-none break-all">
                {MONSTER_PROFILES.rook.lore.replace(/[a-zA-Z]/g, '█')}
              </p>
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                <span className="text-[#FF1E27] font-mono-horror tracking-[0.3em] font-bold border border-[#FF1E27]/50 bg-black/80 px-4 py-1.5 rotate-6 shadow-[0_0_15px_rgba(255,30,39,0.3)]">
                  ENCRYPTED
                </span>
              </div>
            </div>

            {/* Combat & Behavioral Dossier */}
            <div className="relative space-y-3 p-6 bg-black/60 border border-[#FF1E27]/30  overflow-hidden">
              <div className="opacity-40 select-none pointer-events-none grayscale">
                <div className="flex items-center justify-between border-b border-zinc-800 pb-2.5">
                  <span className="text-xs font-mono-horror text-[#FF1E27] flex items-center gap-1.5 uppercase tracking-wider">
                    <ShieldAlert size={14} /> {'UNKNOWN'}
                  </span>
                  <span className="text-xs font-mono-horror text-zinc-400">
                    HEIGHT: {'██████'}
                  </span>
                </div>

                <div className="space-y-2 pt-1 font-mono-horror">
                  {MONSTER_PROFILES.rook.traits.map((trait, idx) => (
                    <div key={idx} className="flex items-start gap-2 text-xs text-zinc-500">
                      <span className="text-[#FF1E27] font-bold">•</span>
                      <span className="break-all">{trait.replace(/[a-zA-Z]/g, '█')}</span>
                    </div>
                  ))}
                </div>

                {/* Gameplay Mechanics Grid for Rook's Domain */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-3 border-t border-zinc-800/80">
                  <div className="p-3 bg-black/40 border border-[#FF1E27]/30 hover:border-[#FF1E27]/60 transition-colors space-y-1">
                    <div className="flex items-center gap-1.5 text-[#FF1E27] font-mono-horror text-xs font-bold uppercase">
                      <Skull size={13} /> INGREDIENT 03: ██████████
                    </div>
                    <p className="text-[11px] text-zinc-500 leading-relaxed font-mono-horror break-all">
                      {"Chipped from the hardened husks left in Rook's wake. Essential for grounding the volatile concoction.".replace(/[a-zA-Z]/g, '█')}
                    </p>
                  </div>

                  <div className="p-3 bg-black/40 border border-zinc-900 hover:border-zinc-700 transition-colors space-y-1">
                    <div className="flex items-center gap-1.5 text-zinc-300 font-mono-horror text-xs font-bold uppercase">
                      <Zap size={13} /> THE FINAL RITUAL
                    </div>
                    <p className="text-[11px] text-zinc-500 leading-relaxed font-mono-horror break-all">
                      {"Once brewed, the potion must be shattered upon the Abyssal Warden's core to sever the curse's anchor.".replace(/[a-zA-Z]/g, '█')}
                    </p>
                  </div>
                </div>
              </div>
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-10">
                <span className="text-[#FF1E27] font-mono-horror tracking-[0.3em] font-bold border border-[#FF1E27]/50 bg-black/80 px-4 py-1.5 -rotate-3 shadow-[0_0_15px_rgba(255,30,39,0.3)]">
                  ENCRYPTED
                </span>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
});
