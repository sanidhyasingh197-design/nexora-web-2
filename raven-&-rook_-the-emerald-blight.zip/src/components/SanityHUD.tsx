import React from 'react';
import { AlertTriangle, Compass, ChevronDown } from 'lucide-react';
import { MANOR_CHAPTERS } from '../data/manorData';

interface SanityHUDProps {
  scrollProgress: number; // 0.0 to 1.0
  activeMonster: 'raven' | 'rook' | null;
  onScrollDown: () => void;
}

export const SanityHUD: React.FC<SanityHUDProps> = ({
  scrollProgress,
  activeMonster,
  onScrollDown,
}) => {
  // Current depth calculation (0 to 180m)
  const currentDepth = Math.round(scrollProgress * 180);

  // Current active chapter
  const currentChapter =
    MANOR_CHAPTERS.slice()
      .reverse()
      .find((c) => scrollProgress >= c.scrollProgress - 0.05) || MANOR_CHAPTERS[0];

  return (
    <>
      {/* Monster Proximity Alert Banner (Top Center) */}
      {activeMonster && (
        <div className="fixed top-20 left-1/2 -translate-x-1/2 z-30 pointer-events-none animate-bounce">
          <div className="px-5 py-2.5 bg-black/90 border border-red-500 shadow-[0_0_25px_rgba(255,0,0,0.6)] flex items-center gap-3 text-red-200 ">
            <AlertTriangle className="text-red-400 animate-ping" size={18} />
            <div className="font-mono-horror text-xs tracking-wider">
              <span className="font-bold text-white uppercase">
                ENTITY DETECTED: {activeMonster === 'raven' ? 'RAVEN (AVIAN STALKER)' : 'ROOK (TOXIC GOLIATH)'}
              </span>
              <div className="text-[10px] text-red-300/80">
                {activeMonster === 'raven' ? 'LOOK UP • SILENCE MOVEMENTS' : 'AVOID RUNNING • STAND CLEAR OF CHASM'}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Left Bottom HUD: Depth & Zone Sensor */}
      <div className="fixed bottom-6 left-4 md:left-8 z-30 pointer-events-none flex flex-col gap-2.5 font-serif max-w-xs sm:max-w-sm">
        {/* Depth & Zone Widget */}
        <div className="bg-black/85  p-3 border-l-2 border-l-[#FF1E27]/50 border border-zinc-900 shadow-[0_0_20px_rgba(0,0,0,0.8)] min-w-[220px]">
          <div className="flex items-center justify-between text-[11px] font-mono-horror text-[#FF1E27] mb-1 tracking-wider uppercase">
            <span className="flex items-center gap-1.5">
              <Compass size={13} /> DESCENT DEPTH
            </span>
            <span className="text-white font-bold font-mono-horror">{currentDepth}m</span>
          </div>

          {/* Depth progress bar */}
          <div className="w-full h-1.5 bg-black rounded-full overflow-hidden border border-zinc-800">
            <div
              className="h-full bg-[#FF1E27] transition-all duration-300 shadow-[0_0_8px_#FF1E27]"
              style={{ width: `${scrollProgress * 100}%` }}
            />
          </div>

          <div className="flex justify-between items-center mt-1.5 text-[10px] font-mono-horror">
            <span className="text-zinc-400 uppercase tracking-widest truncate max-w-[160px]">
              {currentChapter.number}. {currentChapter.shortTitle}
            </span>
            <span className="text-[#FF1E27] font-mono-horror">-{currentDepth}m</span>
          </div>
        </div>
      </div>

      {/* Center Bottom Scroll Indicator (Fades out near bottom) */}
      {scrollProgress < 0.92 && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-30 pointer-events-auto">
          <button
            id="scroll-down-hint-btn"
            onClick={onScrollDown}
            className="group flex flex-col items-center gap-1 text-[#FF1E27] hover:text-white transition-all cursor-pointer"
          >
            <span className="text-[10px] uppercase font-mono-horror tracking-widest opacity-80 group-hover:opacity-100">
              DESCEND INTO MANOR
            </span>
            <div className="w-8 h-8 rounded-full bg-black border border-[#FF1E27]/50 flex items-center justify-center group-hover:border-[#FF1E27] group-hover:shadow-[0_0_15px_rgba(255,30,39,0.4)] transition-all">
              <ChevronDown size={18} className="animate-bounce text-[#FF1E27]" />
            </div>
          </button>
        </div>
      )}
    </>
  );
};
