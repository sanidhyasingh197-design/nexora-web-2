export interface ChapterInfo {
  id: string;
  number: string;
  title: string;
  shortTitle: string;
  subtitle: string;
  depth: number; // depth in meters (e.g. 0 to 180m)
  scrollProgress: number; // 0.0 to 1.0
  tagline: string;
  description: string;
  quote: string;
  speaker: string;
  dangerLevel: 'LOW' | 'MODERATE' | 'CRITICAL' | 'LETHAL';
}

export interface MonsterProfile {
  name: string;
  alias: string;
  brother: string;
  description: string;
  lore: string;
  traits: string[];
  threatClass: string;
  height: string;
  weakness: string;
  soundCue: string;
  imageTheme: string;
}

export interface Artifact {
  id: string;
  name: string;
  origin: string;
  description: string;
  loreFragment: string;
  toxicRating: string;
  color: string;
  geometryType: 'vial' | 'mask' | 'chitin' | 'crucible';
}

export interface AudioLog {
  id: string;
  title: string;
  date: string;
  speaker: string;
  duration: string;
  transcript: string;
}

export interface SystemRequirements {
  minimum: {
    os: string;
    processor: string;
    memory: string;
    graphics: string;
    directx: string;
    storage: string;
  };
  recommended: {
    os: string;
    processor: string;
    memory: string;
    graphics: string;
    directx: string;
    storage: string;
  };
}
